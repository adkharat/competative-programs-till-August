#include<iostream>
#include<bits/stdc++.h>

using namespace std;

//0/1 Knapsack Problem
//Given weights and values of n items, put these items in a knapsack of capacity W to get the maximum total value in the knapsack

struct item
{
	int wt;
	int profit;
};

int solveKS(item item[], int n, int sum) {
	int DP[n + 1][sum + 1];

	for (int i = 0; i <= n; i++) {
		for (int j = 0; j <= sum; j++) {
			if (i == 0 || j == 0)
				DP[i][j] = 0;
			else if (item[i - 1].wt <= j) //if item weight is less than KS weight then we can include it in KS
				DP[i][j] = max(DP[i - 1][j - 1], item[i - 1].profit + DP[i - 1][j - item[i - 1].wt]);
			else //if item weight is greater than KS weight then we left with exclude
				DP[i][j] = DP[i - 1][j - 1];
		}
	}

	return DP[n][sum];
}


int main() {

	int n; cin >> n;
	item it[n];

	for (int i = 0; i < n; i++) {
		int w; cin >> w;
		int p; cin >> p;
		it[i].wt = w;
		it[i].profit = p;
	}
	int sum; cin >> sum;

	cout << "maximum Profit with 0/1 KS " << solveKS(it, n, sum) << endl;

	return 0;
}