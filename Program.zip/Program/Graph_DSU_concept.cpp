#include<iostream>
#include<bits/stdc++.h>
#define pb push_back

using namespace std;

class DSU {

	vector<int> parent;
	int total_comp;

public:

	//Initially parent of every node is itself only
	void init(int nn) {
		parent.clear(); parent.resize(nn);
		//iota(parent.begin(), parent.end(), 0);
		for (int i = 0; i < nn; i++)
			parent[i] = i;
		total_comp = nn;
	}

	int get_superparent(int x) {
		if (parent[x] == x)return x;
		else return parent[x] = get_superparent(parent[x]);
	}

	//Merge/union of disjoint component
	void union_compo(int x, int y) {
		int superParent_x = get_superparent(x);
		int superParent_y = get_superparent(y);
		if (superParent_x != superParent_y) {
			parent[superParent_x] = superParent_y;
			total_comp--;
		}
	}

	void printComp(int n) {
		cout << "Total Component after union " << total_comp << endl;

		for (int i = 0; i < n; i++) cout << parent[i] + 1 << " ";

	}


};

int main() {

	int n, m; cin >> n >> m;
	//To store edges{x,y,wt} use 2D-Array
	//We have m edges 0,1,2,...m. At each index store one edge;
	vector<vector<int>> edges(m);

	//Take input this edges
	for (int i = 0; i < m; i++) {
		int x, y; cin >> x >> y ; //Get input in 1 based indexing
		x--; y--; //Convert back to 0 based indexing
		edges[i] = {x, y}; //store 2 Columns at each row index
	}

	DSU g;

	g.init(n);//index 0 to (n-1) //0 based INDEX

	for (int i = 0; i < m; i++)
	{
		int x = edges[i][0];
		int y = edges[i][1];

		g.union_compo(x, y);

	}

	g.printComp(n);

	return 0;
}

/*
5 2
1 2
3 4
*/