#include<iostream>
#include<bits/stdc++.h>

using namespace std;

//SLIDING Window + Deque
int main()
{

	int n; //no. of element in array
	int arr[100000]; //array can hold element upper bound
	int k;//window size


	cin >> n;

	for (int i = 0; i < n; i++)cin >> arr[i];

	cin >> k;

	int i;
	deque<int> Q(k);
	//we have to process 1st k elemt separately
	for (i = 0; i < k; i++) {
		while (!Q.empty() and arr[i] > arr[Q.back()]) { //element back of queue smaller than curr array element  then remove those.
			Q.pop_back();
		}

		Q.push_back(i);
	}



//Process for remaining element
	for (i; i < n; i++) {
		cout << arr[Q.front()] << " ";

		//1. remove the elemt which are not part of current window(contraction)
		while (!Q.empty() and (Q.front() <= i - k)) {
			Q.pop_front();
		}

		//2. remove the element which are not useful

		while (!Q.empty() and (arr[i] >= arr[Q.back()])) {
			Q.pop_back();
		}


		//3. Add new element(expansion)

		Q.push_back(i);

	}

	cout << arr[Q.front()] << endl;

	return 0;

}

