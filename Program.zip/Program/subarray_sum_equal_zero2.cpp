#include<iostream>
#include<bits/stdc++.h>

using namespace std;

//Subarray sum = 0 using PREFIX Array + Set container
//Prefix[j] - prefix[i] = 0 ==>arr_sum(i+1 ,j)

int main()
{
	int arr[] = {1, 2, 4, -4, 5};

	int n = sizeof(arr) / sizeof(arr[0]);

	int prefix[n] = {0};
	prefix[0] = arr[0];

	for (int i = 1; i < n; i++)
		prefix[i] = prefix[i - 1] + arr[i];

	for (int i = 0; i < n; i++)
	{
		cout << arr[i] << " ";
	}
	cout << endl;
	for (int i = 0; i < n; i++)
	{
		cout << prefix[i] << " ";
	}

	cout << endl;
	//arr[]    = {1, 2, 4, -4, 5};
	//Prefix[] = {1, 3, 7,  3, 8};
	set<int> s;
	for (int i = 0; i < n; i++)
	{
		auto it = s.find(prefix[i]);
		if (it == s.end())
			s.insert(prefix[i]);
		else
			cout << "Subarray exist with sum is zero";

	}

	for (auto ele : s)
	{
		cout << ele << " ";
	}
	return 0;
}