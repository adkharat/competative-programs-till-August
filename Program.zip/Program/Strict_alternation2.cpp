#include <iostream>
#include <thread>
#include <mutex>
#include <condition_variable>
using namespace std;
mutex mu;
condition_variable cond;
int count = 1;

void PrintOdd()
{
  while (1)
  {
    mu.lock();
    if (count % 2 != 0)
    {
      cout << "I am odd" << count << endl;
      count++;
    }
    if (count > 100)
      break;
    mu.unlock();
  }

}

void PrintEven()
{
  while (1)
  {
    mu.lock();
    if (count % 2 == 0)
    {
      cout << " I am Even" << count << endl;
      count++;
    }
    if (count == 100)
      break;
    mu.unlock();
  }
}

int main()
{
  thread t1(PrintOdd);
  thread t2(PrintEven);
  t1.join();
  t2.join();
  return 0;
}