#include<iostream>
#include<bits/stdc++.h>
#include<climits>

using namespace std;

int ways(int *no_ways, int n, int m)
{
	no_ways[0] = 1;
	no_ways[1] = 1;

	for (int i = 2; i <= n; i++)
	{
		for (int j = 1; j <= m and j <= i; j++) //I can climb atmost m steps on ladder
			no_ways[i] += no_ways[i - j];

		cout << i << "th step:- " << no_ways[i] << endl;
	}

	return no_ways[n];

}


//How many ways I can reach ith step of a ladder
int main()
{
	int t; cin >> t;

	while (t--)
	{
		int n; cin >> n; //ow many ways I can reach nth step of a ladder?
		int m; cin >> m; //Atmost 'm' steps , I can climb at a time.(0,1,2,3,4....)

		int *no_ways = new int[n + 1]; //0 to nth step = n+1 steps

		for (int i = 0; i <= n; i++)
			no_ways[i] = 0;

		cout << "No. of ways " << ways(no_ways, n, m) << endl;

	}


	return 0;
}