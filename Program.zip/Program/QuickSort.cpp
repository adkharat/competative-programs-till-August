#include<bits/stdc++.h>

using namespace std;


int partition(int *arr, int s, int e)
{
	int i = s - 1;   //keep track of element less than Pivot element
	int j = s;

	int pivot = arr[e]; //Let last element of array is pivot
//J travel through array until pivot-1
	for ( ; j <= e - 1 ; j++) //J travel till pivot-1
	{
		if (arr[j] <= pivot) {
			i = i + 1;
			swap(arr[i], arr[j]); //Incre i and swap arr[i] with arr[j]
		}
	}
	swap(arr[i + 1], arr[e]); //Swap pivot with i+1

	return i + 1; //Return pivot index


}



void QuickSort(int *arr, int s, int e)
{

//Base case
	if (s >= e)
		return ;

	//Calll partiotin to fix pivot element

	int p = partition(arr, s, e);
	//Left of partiton
	QuickSort(arr, s, p - 1);
	//Right of partition
	QuickSort(arr, p + 1, e);
}


int main()
{

	int arr[] = {10, 9, 8, 7, 6, 5};

	int n = sizeof(arr) / sizeof(arr[0]);


	QuickSort(arr, 0, n - 1);
	cout << endl;
	for (int i = 0; i < n; i++)
		cout << arr[i] << " ";
	cout << endl;


	return 0;
}