#include <iostream>
using namespace std;
//Here is no. of Bits available
int count(int n) {

	if (n == 1 || n == 2)
		return n;
	return count(n - 1) + count(n - 2);


}


int main()
{
	cout << count(4) << endl;
	return 0;
}