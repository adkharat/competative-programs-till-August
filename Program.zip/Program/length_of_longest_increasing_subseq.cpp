#include<iostream>
#include<bits/stdc++.h>
#include<climits>

using namespace std;

int main()
{
	int t; cin >> t;

	while (t--)
	{
		int n; cin >> n;

		int arr[n];

		for (int i = 0; i < n; i++)
			cin >> arr[i];

		int len[n];
		int index[n];
		for (int i = 0; i < n; i++) {
			len[i] = 1; 			//each individual character of string is subseq of length 1
			index[i] = 0;
		}


		for (int i = 1; i < n; i++) //Subseq of length = 2 to n
		{
			for (int j = 0; j < i; j++)
			{
				//Check if new item can be appended to subseq (new item  > old item in subseq); if yes then increase the new item subseq length
				if (arr[j] < arr[i]) {
					len[i] = max(len[i], len[j] + 1);
					index[i] = j;
				}


			}
		}

		for (int i = 0; i < n; i++) {
			cout << index[i] << " ";

		}
		cout << endl;

		int tmp = len[n - 1];
		vector<int> v;
		for (int i = n - 1; i >= 0; i--) {
			if (tmp == len[i]) {
				v.push_back(i);
				tmp--;
			}

		}

		reverse(v.begin(), v.end());
		for (int x : v) {
			cout << "Index " << x << " ";
//
		}
		cout << endl;

		cout << endl;

		cout << "length of longest incresing subseq " << len[n - 1] << endl;

	}



	return 0;
}