
#include <iostream>
#include<bits/stdc++.h>
#define F first
#define S second
#define pb push_back
#define mp make_pair

using namespace std;

template<typename T>
class Graph
{
	map<T, list<pair<T, int>>> m;

public:

	void addedge(T x , T y, int wt) {

		m[x].pb(mp(y, wt));
		m[y].pb(mp(x, wt));
	}

	void printadjlist()
	{
		for (auto node_pair : m)
		{
			cout << node_pair.F << "-->";
			for (auto nbr : node_pair.S)
			{
				cout << "(" << nbr.F << "," << nbr.S << ")";
			}
			cout << endl;
		}
	}

	void dijkstra(T src)
	{
		map<T, int> distance; //shortest distance of each node from source node
		set<pair<int, T> > s; //hold vertex which are relaxed --> select mini form those --> fix it(delete it)

		//Initially distance of each vertex to infinity
		for (auto node_pair : m)
		{
			T node = node_pair.F;
			distance[node] = INT_MAX;
		}

		distance[src] = 0;
		s.insert(mp(0, src));

		while (!s.empty())
		{
			//Get minimum from set--> first element is minimum in set
			auto it = s.begin();

			int wt = it->first; // *(it).first
			T node = it->S; // *(it).second

			//Fix that node-->Shortest distance is finalize --> delete it
			s.erase(it);

			//Relax all its outgoing edges (neighburs)

			for (auto nbrs : m[node])
			{
				T name = nbrs.F;
				int dis = nbrs.S;

				if (distance[name] > wt + dis) {

					//For source node this find part will not work.
					auto add = s.find(mp(distance[name], name)); //can't update set -->delete and insert same node, s first find it (set-->pair(distance , node))
					if (add != s.end())
						s.erase(add);

					s.insert(mp(wt + dis, name)); //updated the neighburs dhortest distance in set
					distance[name] = wt + dis ; //updated the neighburs dhortest distance in distance array
				}
			}

		}

		for (auto node_pair : m )
		{
			T node = node_pair.F;
			cout << node << "--> " << distance[node] << endl;

		}

	}






};

int main()
{
	Graph<int> g;

	g.addedge(1, 2, 1);
	g.addedge(1, 3, 4);
	g.addedge(1, 4, 7);
	g.addedge(2, 3, 1);
	g.addedge(3, 4, 2);


	g.printadjlist();

	g.dijkstra(1);



	return 0;
}