#include <bits/stdc++.h>
using namespace std;

class Graph {

	int V;
	list<int> *l;

public:

	Graph(int V) {
		this->V = V;
		l = new list<int>[V];
	}

	void addEdge(int x, int y) {
		l[x].push_back(y);
		l[y].push_back(x);
	}

	void printAdjList() {

		for (int i = 0; i < V; i++) {
			cout << "Vertex " << i << "--> ";
			for (auto x : l[i])
				cout << x << " ";
			cout << endl;
		}
	}

	void DFSUtil(int src, bool visited[]) {

		visited[src] = true;
		cout << src << " ";

		//Travel all its neighbour
		for (auto x : l[src]) {
			if (!visited[x])
				DFSUtil(x, visited);
		}

	}


	//DFS travesal from arbitary source X
	//To get out of loop in graph maintain VISISTED array
	void DFS(int src) {

		bool *visited = new bool[V] {0};

		//DFSUtil(src, visited);

		/*To find no. of connected componenet in graph
		call DFS on ever graph vertex*/
		/*int count = 0;
		for (int i = 0; i < V; i++) {
			if (!visited[i]) {
				DFSUtil(i, visited);
				count++;
			}
		}

		cout << "No of componenet in Graph " << count << endl;
		}*/


	};

	int main() {

		int n, e; cin >> n >> e;
		Graph g(n);

		while (e--) {
			int x, y; cin >> x >> y;
			g.addEdge(x, y);
		}

		g.printAdjList();
		int src; cin >> src;
		g.DFS(src);

		return 0;
	}