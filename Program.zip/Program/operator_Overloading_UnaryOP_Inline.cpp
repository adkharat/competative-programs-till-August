#include<iostream>
#include<unistd.h>
#include<sys/types.h>
using namespace std;


class increm {

	int a;

public:
	//For i3 object we need constructor of this type
	// increm() {
	// 	a = 0;
	// }

	//For i1 object we need constructor of this type
	// increm(int ai) {
	// 	a = ai;
	// }

	//For i1 and i2 object we need constructor of below type
	//Combination of default constructor and parameterised constructor
	increm(int a = 0) {
		this->a = a;
	}

	//OPerator overloading unary operator
	//one operand is passed implicit
	increm operator + () {
		increm i3;
		i3.a = ++a;

		return i3;
	}

	void display() {
		cout << " a= " << a << endl;
	}

};

int main() {

	increm i1(5);
	i1.display();

	increm i3;
	i3 = +i1;

	i3.display();


	return 0;
}