#include <bits/stdc++.h>
using namespace std;

class Graph {
	int V;
	list<int> *l;

public:

	Graph(int v) {
		this->V = v;
		l = new list<int>[V];
	}

	void addedge(int x, int y) {
		l[x].push_back(y);
	}

	bool dfs_helper(int src, bool *visited, bool *stack) {
		//When enter the path, Push it in Stack.
		visited[src] = true;
		stack[src] = true;

		for (int i = 0; i < V; i++) {
			for (auto nbr : l[i])
			{
				if (!visited[nbr]) {
					if (dfs_helper(nbr, visited, stack)) //src node will ask next nbr do it contain cycle?
						return true;
				}
				else if (stack[nbr] == true) //Else Nbr is visited and stack[nbr] = true. It means nbr is present in current path
					return true;//Backedge is present while backtracking;
			}
		}



		//When returning back pop node from stack. Hence from Path
		stack[src] = false;
		return false;
	}

	bool cycle_directed_graph_dfs() {
		bool *visited = new bool[V];
		bool *stack = new bool[V]; //To capture the path travel (cycle) in a stack.

		for (int i = 0; i < V; i++) {
			visited[i] = false;
			stack[i] = false;
		}

		if (dfs_helper(0, visited, stack))
			return true;

		return false;
	}


};

int main() {

	int n, e; cin >> n >> e;
	Graph g(n);

	for (int i = 0; i < e; i++) {
		int x, y; cin >> x >> y;
		g.addedge(x, y);
	}

	g.cycle_directed_graph_dfs() ? cout << "Cycle is present \n " : cout << "Cycle Not present \n";

	return 0;
}


/* Graph g(4);
    g.addEdge(0, 1);
    g.addEdge(0, 2);
    g.addEdge(1, 2);
    g.addEdge(2, 0);
    g.addEdge(2, 3);
    g.addEdge(3, 3);
    */