#include<iostream>
#include<algorithm>
#include<string>
#include <bits/stdc++.h>
using namespace std;

bool compare(string a, string b){
    if(a.length() == b.length())
        return a<b;
    else
        return a.length() < b.length();
}

int main()
{

    string s;
    string tmp;
    int count=0;
    //cin>>s;
    getline(cin,s);

    stringstream str_stm(s);

    while(str_stm >> tmp){
    count++;
    }


    cout<<count<<endl;


    return 0;

}
