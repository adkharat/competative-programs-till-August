#include<iostream>
#include<bits/stdc++.h>

using namespace std;

void printsubarray(vector<int> v, int s, int e)
{
	int sum = 0;
	for (int i = s; i <= e ; i++) {
		sum += v[i];
	}
	{
		if (sum == 0) {
			cout << "Sum = " << sum << " ";
			for (int x = s; x <= e; x++)
				cout << v[x] << " ";
		}
	}


}

void generate_subarray(vector<int> v, int n)
{
	for (int s = 0; s < n; s++)
	{
		for (int e = s; e < n; e++) {
			printsubarray(v, s, e);
		}

	}
}

int main()
{
	vector<int> v;
	int n; cin >> n;

	for (int i = 0; i < n; i++)
	{
		int x; cin >> x;
		v.push_back(x);
	}

	generate_subarray(v, n);



	return 0;
}