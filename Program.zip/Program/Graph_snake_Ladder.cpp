#include <bits/stdc++.h>
using namespace std;

struct queueEntry {
	int V;	//Vertex number
	int dist; // Distance of this vertex from source
};

int getminimumDiceThrow(int MOVE[], int N) {

	//We will treavel similar toBFS where distance of each nbrs node is +1 from curr node
	//Not to fall in loop use VISITED array
	bool *visited = new bool[N] {0};

	//Queue for BFS traversal
	queue<queueEntry> q;

	visited[0] = 1;
	queueEntry s = {0, 0}; //Dist of Source vertex to source is 0
	q.push(s);


	queueEntry qe; //For processing queue element
	while (!q.empty()) {
		qe = q.front();
		int v = qe.V;

		q.pop();

		//ENQUE its neighbours in Queue.
		//It can have 6 neighbours in directed graph based on dice outcome
		for (int j = v + 1; j <= v + 6 and j < N; j++)
			if (!visited[j]) //If neighbior is unvisited then push it in queue.To push we need {vertes , dist from src}
			{
				queueEntry a;
				a.dist = (qe.dist) + 1;
				visited[j] = true;

				if (MOVE[j] != -1)
					a.V = MOVE[j];
				else
					a.V = j;

				q.push(a);
			}

	}

	// We reach here when 'qe' has last vertex
	// return the distance of vertex in 'qe'
	return qe.dist;
}

int main() {

	int N = 30;
	int MOVE[N] = { -1}; //Initially all vertices are marked as -1; //Index{0...N-1}

	//ladder
	MOVE[2] = 21;
	MOVE[4] = 7;
	MOVE[10] = 25;
	MOVE[19] = 28;

	//Snake
	MOVE[16] = 3;
	MOVE[20] = 8;
	MOVE[18] = 6;
	MOVE[26] = 0;

	cout << "Minimum Dice Throw " << getminimumDiceThrow(MOVE, N) << endl;


	return 0;
}