#include<bits/stdc++.h>

using namespace std;

int power(int n, int p)
{
	if (p == 0)
		return 1;

	int no = power(n, p / 2);
	if ((p & 1) == 1)
		return n * no * no;
	else
		return no * no;
}

int main()
{
	int n, p; cin >> n >> p;

	cout << "fast power " << power(n, p) << endl;

	return 0;
}