#include <iostream>
#include <bits/stdc++.h>

using namespace std;

void printsubseq(char subseq_arr[], int css_idx) {
	cout << "{ ";
	for (int i = 0; i < css_idx; i++)
		cout << subseq_arr[i] << " ";
	cout << "}";

	cout << endl;

}

void generate_subseq(char arr[], int n, int curr_idx, char subseq_arr[], int  s_arr_idx) {

	if (curr_idx >= n) {

		printsubseq(subseq_arr, s_arr_idx);
		return;
	}

	subseq_arr[s_arr_idx] = arr[curr_idx];							//subseq_arr array Hold one subseq at a time.
	//cout << subseq_arr << " " << arr;
	generate_subseq(arr, n, curr_idx + 1, subseq_arr, s_arr_idx + 1); //Include the current elemet from array to subseq array.
	generate_subseq(arr, n, curr_idx + 1, subseq_arr, s_arr_idx);   //Exclude the current elemet from array to subseq array.

}

int main()
{
	string  s1;
	cin >> s1;
	char input[s1.length()] = {s1};
	int n = sizeof(input) / sizeof(input[0]);

	char subseq_arr[n];

	generate_subseq(input, n, 0, subseq_arr, 0);

	return 0;
}