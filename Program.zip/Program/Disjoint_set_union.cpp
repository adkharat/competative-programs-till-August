#include<iostream>
#include<bits/stdc++.h>

using namespace std;


class DSU
{

	vector<int> parent;
	vector<int> node_count; //Count node in each compomenet
	int total_comp;

public:

	//Initially parent of every node is itself only
	void init(int nn)
	{
		parent.clear(); parent.resize(nn);
		iota(parent.begin(), parent.end(), 0);
		node_count.clear(); node_count.resize(nn);
		iota(node_count.begin(), node_count.end(), 0);
		for (int i = 0; i < nn; i++) parent[i] = i;
		for (int i = 0; i < nn; i++) node_count[i] = i; //Initially node count is 1
		//If I want to get total component
		total_comp = nn;
	}

	//Get super_parent of a node using PATH compression O(1) time complexity
	int get_superparent(int x)
	{
		if (parent[x] == x)
			return x;
		else
			return parent[x] = get_superparent(parent[x]);

	}

	//Merge/union of disjoint component
	void union_compo(int x, int y) {

		int x_super = get_superparent(x);
		int y_super = get_superparent(y);

		if (x_super != y_super) {
			parent[x_super] = y_super; //Change parents

			node_count[y_super] += node_count[x_super]; //update node count
			node_count[x_super] = 0; //x dobate its node count to y
			total_comp--; //after union total component reduces by 1 bcs of merging of 2 comp at a time
		}

	}

	void printcomp(int n)
	{
		cout << endl << "total Comp " << total_comp << endl;

		for (int i = 0; i < n; i++) {
			cout << parent[i] << " " << node_count[i] << " " << endl;
		}

	}



};


int main()
{

	DSU g;
	int n, m; cin >> n >> m;

	g.init(n);

	for (int i = 0; i < m; i++)
	{
		int x, y; cin >> x >> y;
		g.union_compo(x, y);
	}

	g.printcomp(n);

	return 0;
}