#include<cstdio>
#include <bits/stdc++.h>

using namespace std;





int main() {


	char arr[] = { 'G', 'F', 'G' };

	// Calculate the size of char array
	size_t size = sizeof(arr) / sizeof(arr[0]);

	// Print the size of char array
	printf("Size of char array is: %ld byte",
	       size);


	return 0;
}