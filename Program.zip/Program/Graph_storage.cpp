#include<iostream>
#include<bits/stdc++.h>
using namespace std;

//Representation of Graph using adj list
class Graph
{

	int V;

	list<int> *l;

public:

	Graph(int v) {
		this->V = v;
		l = new list<int>[V];
	}

	void addnode(int src, int dest) {
		l[src].push_back(dest);
		l[dest].push_back(src);
	}

	void display()
	{

		for (int i = 0; i < V; i++) {
			cout << i << "-->";
			for (auto x : l[i]) {
				cout << x << ",";
			}
			cout << endl;
		}
	}




};

int main()
{
	int vertex;
	cout << "Enter no of Vertex in Graph ";
	cin >> vertex;
	Graph g(vertex);

	g.addnode(0, 1);
	g.addnode(1, 2);
	g.addnode(2, 0);

	g.display();



	return 0;
}
