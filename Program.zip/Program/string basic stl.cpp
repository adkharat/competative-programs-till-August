#include<iostream>
#include<string>
#include<algorithm>

using namespace std;

int main()
{
    string s1="Ajay";
    string s2("Kharat");
    char *str1 = "Ajay";
    char str2[] = {'a','j','a','y','\0'};
    string s3(s1);
    string s4 = s2;

    string s5(str1);
    string s6;

    cout<<s1<<endl;
    cout<<s2<<endl;
    cout<<s3<<endl;
    cout<<s4<<endl;
    cout<<s5<<endl;

    if(s6.empty())
        cout<<"string is empty: "<<s6<<endl;

    s6.append("I love pyhton");

    if(s6.empty())
        cout<<"string is empty: "<<s6<<endl;
        else{
        s6=s6+ " and c++";
        cout<<s6<<endl;
        }
    cout<<s1.length()<<endl;
    s1.clear();
    cout<<endl;
    cout<<s1<<" "<<s1.length()<<endl;
    cout<<s3.compare(s2)<<endl;
    cout<<"Hello"<<endl;


    string s7 = "Apple";
    string s8 = "Gango";

    if(s7<s8){
        cout<<"Mango is lexiographicaaly greater than Apple"<<endl;
    }
    if(s7.compare(s8)){
        cout<<"Mango is lexiographicaaly greater than Apple   "<<s7.compare(s8)<<endl;
    }

    string s = "i love mango juice";

    string i = "mango";

    int idx = s.find(i);

    int len = i.length();
    cout<<i<<" index = "<<idx<<"length is "<<len<<endl;

    s.erase(idx,len+1);

    cout<<"string after "<<s<<endl;

    for(int i=0; i<s7.length() ; i++)
        cout<<s7[i];
    cout<<endl;
        cout<<endl;





    for(auto it = s7.begin(); it != s7.end(); it++)
        cout<<*it<<" ";
    cout<<endl;

    for(char c : s7)
        cout<<c<<" ";
cout<<endl;

    return 0;
}
