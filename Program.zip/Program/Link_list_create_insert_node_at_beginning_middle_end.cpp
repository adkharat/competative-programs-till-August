#include<bits/stdc++.h>

using namespace std;

class node
{
public:
	int data;
	node *next;
};

/* Given a reference (pointer to pointer)
to the head of a list and an int, inserts
a new node on the front of the list. */
void push_front(node **head_ref, int new_data) {

	node *new_node = new node();

	new_node->data = new_data;

	new_node->next = (*head_ref);
	(*head_ref) = new_node;

}


/* Given a node prev_node, insert a new node after the given
prev_node */
void push_after(node **head_ref, int prev_node_data, int new_data) {

	node *new_node = new node();

	new_node->data = new_data;

	node *temp = (*head_ref);

	while (temp->data != prev_node_data)
		temp = temp->next;

	new_node->next = temp->next;
	(temp->next) = new_node;

	return;
}


/* Given a reference (pointer to pointer) to the head
of a list and an int, appends a new node at the end */
void append(node **head_ref, int new_data) {

	node* new_node = new node();


	new_node->data = new_data;
	new_node->next = NULL;


	if ((*head_ref) == NULL) {
		(*head_ref) = new_node;
		return ;
	}

	node *temp = (*head_ref);

	while (temp->next != NULL)
		temp = temp->next;

	temp->next = new_node;

	return;

}

void printList(node **head_ref) {
	node *temp = (*head_ref);

	while (temp != NULL) {
		cout << temp->data << " ";
		temp = temp->next;
	}
}

int main() {

	node *head  = NULL;

	append(&head, 5);
	append(&head, 6);
	append(&head, 7);

	push_front(&head, 4);
	push_front(&head, 3);


	push_after(&head, 5, 6);
	printList(&head);


	return 0;
}