#include<bits/stdc++.h>
using namespace std;

class LRUCache {

	int cachesize;

//Doublly link-list to sort newest and oldest element
	queue<int> dl;

//Efficiently seacrh <key, address of cache element>
	unordered_set<int> mp;

public:
//constructor to initilize cache 4 frames
	LRUCache(int size) {
		cachesize = size;
	}


//one by one make reference
	void cacheReference(int x)
	{
		//Cache Miss

		//Cache is full and miss
		if (mp.find(x) == mp.end()) { //cache misss
			if (dl.size() == cachesize) { //cache is full
				//back of queue we have oldest element
				//front of queue we have newest element
				//delet oldest element

				//make space for new element
				int first = dl.front();

				dl.pop();

				mp.erase(first);

				dl.push(x);

				mp.insert(x);

			}
			else
			{
				dl.push(x);

				mp.insert(x);
			}
		}
		//else //Cache has referenced element. simply bring it to newest element


	}


	void display() {
		while (!dl.empty()) {
			cout << " " << dl.front();
			dl.pop();
		}
	}
};

int main() {

	LRUCache ca(4);

	ca.cacheReference(1);
	ca.cacheReference(2);
	ca.cacheReference(3);
	ca.cacheReference(1);
	ca.cacheReference(4);
	ca.cacheReference(5);

	ca.display();

	return 0;
}