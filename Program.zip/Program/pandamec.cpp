#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    int T; cin >> T;
    int N; cin >> N;
    int K; cin >> K;
    vector<pair<int, int>> v[N];
    int sum = 0;
    for (int i = 0; i < N; i++) {
        int x, y; cin >> x >> y;
        v[i].push_back(make_pair(x, y));
        int pro = x * y;
        sum += pro;
    }
    if (sum < K)
        cout << "YES" << " " << sum;
    else
        cout << "NO";
    return 0;
}
