#include<iostream>
#include<bits/stdc++.h>

using namespace std;

//Subarray sum = 0 using PREFIX Array + Map container
//Prefix[j] - prefix[i] = 0 ==>arr_sum(i+1 ,j)

bool subarray_sum_zero(int *arr, int n)
{
	set<int> s;
	int prefix = 0;
	for (int i = 0; i < n; i++)
	{
		prefix += arr[i];
//A prefix sum of 0 means subarray whose sum=0 is present
		if (prefix == 0 or s.find(prefix) != s.end()) //s.find(prefix)!=s.end() means element is present inside set
			return true;
		else
			s.insert(prefix); //If prefix sum not present in set , insert it in set.
	}

	return false;

}


//O(n) time in single scan I can tell
//if subarray with sum equal to 0 is present or not
//Time =O(n) and Space=(set)
int main()
{
	int n; cin >> n;

	int *arr = new int [n];




	for (int i = 0; i < n; i++)
	{
		cin >> arr[i];
	}
	cout << endl;


	if (subarray_sum_zero(arr, n))
		cout << "Yes";
	else
		cout << "No";



	return 0;
}