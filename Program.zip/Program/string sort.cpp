#include<iostream>
#include<algorithm>
#include<string>

using namespace std;

bool cmp(string a, string b)
{
    if(a.length()==b.length())
    return a<b;
    else
    return a.length() < b.length();

}

int main()
{


    //string s2;
   // string tmp;
    int n; cin>>n;
    string s[n];
    //cin.get();

    for(int i=0;i<n;i++)
    {
    string no;
    cin>>no;
    s[i]=no;
    }


    sort(s,s+n,cmp);

    for(int i=0;i<n;i++)
        cout<<s[i]<<endl;

    return 0;

}
