#include<bits/stdc++.h>
using namespace std;

int mini_len(vector<int> a) {
	int n; n = a.size();

	int start_index = 0, end_index = n - 1;

	int mini_index, max_index;
	//start index
	for (int i = 0; i < n; i++) {
		if (a[i] > a[i + 1]) {
			start_index = i;
			break;//first unsorted element from start
		}
	}
	//end index
	for (int j = n - 1; j >= 0; j--) {
		if (a[j] < a[j - 1]) {
			end_index = j;
			break;//first unsorted element from end
		}
	}
	//cout << "start_index " << start_index << " end_index " << end_index << endl;

	//return end_index - start_index + 1;
	//Sorting this range don't gurantee always

	//1 4 7 5 10 18 17 26 30 45 50 62 //7 5 10 18 17
	//after sorting 1 4 5 7 10 17 18 26 30 45 50 62 //OK

	//1 4 7 3 10 48 17 26 30 45 50 62 //7 3 10 48 17
	//After sorting 1 4 " 3 7 10 17 48 " 26 30 45 50 62 NOT OK

	int mini_element = *min_element(a.begin() + start_index, a.begin() + end_index);
	int maxi_element = *max_element(a.begin() + start_index, a.begin() + end_index);

	//Now find mini_index form 0 to start_index
	for (int i = 0; i <= start_index; i++) {
		if (a[i] > mini_element)
		{
			mini_index = i;
			break;
		}
	}

	for (int i = n - 1; i >= end_index; i--) {
		if (a[i] < maxi_element)
		{
			max_index = i;
			break;
		}
	}

	cout << "Staring from " << mini_index << "Till " << max_index << endl;

	sort(a.begin() + mini_index, a.begin() + max_index );
	for (auto x : a)
		cout << x << " ";
	cout << endl;

	return max_index - mini_index + 1;

}

int main() {
	int n; cin >> n;
	vector<int> a;

	for (int i = 0; i < n; i++) {
		int x; cin >> x;
		a.push_back(x);
	}

	cout << " " << mini_len(a) << endl;
	return 0;
}