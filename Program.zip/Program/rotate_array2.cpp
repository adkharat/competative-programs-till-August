#include<iostream>

#include<bits/stdc++.h>

using  namespace std;


int g_c_d(int a, int b) {

	if (b == 0)
		return a;
	else
		return g_c_d(b, a % b);
}

vector<int> rotate(vector<int> v, int n, int d) {

	d = d % n;

	int gcd = g_c_d(n, d);



	for (int i = 0; i < gcd; i++) {
		int temp = v[i];
		int j = i;
		while (1) {

			int k = j + d;

			if (k >= n)
				k = k - n;
			if (k == i)
				break;

			v[j] = v[k];
			j = k;
		}
		v[j] = temp;

	}

	return v;

}


int  main() {

	vector<int> v = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};

	int d = 3;

	int n = v.size();


	vector<int> v2 = rotate(v, n, d);

	for (auto x : v2)
		cout << x << " ";


	return 0;
}