#include<bits/stdc++.h>

using namespace std;

void getmin(vector<unsigned int> v, int n) {
	unsigned int res = 0;

	for (int i = 0; i < n; i++)
		res = res ^ v[i];

	cout << UINT_MAX - res << endl;
}

int main() {

	int n; cin >> n;
	vector<unsigned int> v;

	for (int i = 0; i < n; i++) {
		int x; cin >> x;
		v.push_back(x);
	}

	sort(v.begin(), v.end());

	for (int i = n; i > 0; i--) {
		getmin(v, i);
		v.pop_back();
	}

	return 0;
}