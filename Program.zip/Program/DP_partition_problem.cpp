#include<iostream>
#include<bits/stdc++.h>

using namespace std;

bool findPartiion(int arr[], int n) {

	int sum = 0;
	for (int i = 0; i < n; i++)
		sum += arr[i];

	if (sum % 2 != 0)
		return false;

	//similar to SUBSET SUM Problem
	//sum/2+1 ==>Rows and n+1 ==>Colums
	bool DP[n + 1][sum / 2 + 1];


	// initialize top row as true
	for (int i = 0; i <= sum / 2; i++)
		DP[0][i] = false;

	//initialize leftmost column,
	for (int i = 0; i <= n; i++)
		DP[i][0] = true;
	// Fill the partition table in bottom up manner

	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= sum / 2; j++)
		{

			//Exclude
			DP[i][j] = DP[i - 1][j - 1];

			//Include
			DP[i][j] = DP[i][j] || DP[i][j - arr[i - 1]];
		}

	}

	return DP[n][sum / 2];
}

int main() {
	int arr[] = {3, 1, 1, 2, 2, 1};
	int n = sizeof(arr) / sizeof(arr[0]);
	if (findPartiion(arr, n) == true)
		cout << "Can be divided into two subsets of equal sum";
	else
		cout << "Can not be divided into"
		     << " two subsets of equal sum";
	return 0;
}