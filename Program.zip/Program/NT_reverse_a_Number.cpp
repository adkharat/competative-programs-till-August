#include<bits/stdc++.h>

using namespace std;

int main() {

	int n; cin >> n;
	int r;//to get last digit
	int sum = 0; //to store result
	while (n > 0) {
		r = n % 10;
		sum = (sum * 10) + r;
		n = n / 10;
	}

	cout << "Reverse no is " << sum << endl;
	return 0;
}