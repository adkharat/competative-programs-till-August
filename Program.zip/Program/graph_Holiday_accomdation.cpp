#include <bits/stdc++.h>
using namespace std;

class Graph
{
	int V;
	list<pair<int, int> > *l;

public:
	Graph(int v)
	{
		this->V = v;
		l = new list<pair<int, int>>[V];
	}

	void addedge(int x, int y, int cost) {
		l[x].push_back(make_pair(y, cost));
		l[y].push_back(make_pair(x, cost));
	}

	void printAdjList() {
		for (int i = 0; i < V; i++) {
			cout << "Vertex " << i << "-->";
			for (auto x : l[i])
				cout << "(" << x.first << "," << x.second << ")" << " ";
			cout << endl;
		}
	}

	int dfs_helper(int src, bool *visited, int *count, int &ans) {

		visited[src] = true;
		count[src] = 1;

		//travel  unvisited neighbour
		for (auto nbrs : l[src]) {
			int nbr =  nbrs.first;
			int cost = nbrs.second;

			if (!visited[nbr]) {
				count[src] += dfs_helper(nbr, visited, count, ans);
				int x = count[nbr];
				int y = V - x;
				ans += 2 * min(x, y) * cost;
			}

		}

		return count[src];

	}


	int dfs() {
		bool *visited = new bool[V];

		int *count = new int[V];

		for (int i = 0; i < V; i++) {
			visited[i] = false;
			count[i] = 0;
		}

		int ans = 0;
		//dfs_helper(starting node ,visited arry ,count array ,final ans);
		dfs_helper(0, visited, count, ans);


		return ans;
	}

};

int main() {

	int t; cin >> t;
	while (t--) {

		int n; cin >> n;
		Graph g(n);
		int e = n - 1;
		cout << n << " " << e << " " << endl;
		for (int i = 0; i < (n - 1); i++) {
			int x, y, cost; cin >> x >> y >> cost;
			g.addedge(x , y , cost);
		}

		cout << "Ajay ";
		g.printAdjList();

		cout << "Case #" << (t + 1) << ": " << g.dfs() << endl;
	}

	return 0;
}