#include<iostream>
#include<bits/stdc++.h>

using namespace std;

class DSU
{

	vector<int> parent;
	int total_comp;
	int mini_cost;
public:

	//Initially parent of every node is itself only
	void init(int nn)
	{
		parent.clear(); parent.resize(nn);
		iota(parent.begin(), parent.end(), 0);
		for (int i = 0; i < nn; i++)
			parent[i] = i;
		//If I want to get total component
		total_comp = nn;
		mini_cost = 0;
	}

	//Get super_parent of a node using PATH compression O(1) time complexity
	int get_superparent(int x)
	{
		if (parent[x] == x)
			return x;
		else
			return parent[x] = get_superparent(parent[x]);

	}

	//Merge/union of disjoint component
	void union_compo(int x, int y, int z) {

		int x_super = get_superparent(x);
		int y_super = get_superparent(y);

		if (x_super != y_super) {
			parent[x_super] = y_super;
			total_comp--; //after union total component reduces by 1 bcs of merging of 2 comp at a time
			mini_cost += z;

			cout << x << "--> " << y  << " ," << z  << "mini_cost--> " << mini_cost << endl;
		}
	}

	void printcomp()
	{
		cout << endl << "total Comp " << total_comp << endl;
	}



};



int main()
{


	int n, m; cin >> n >> m; //input n vertex and m edges
	vector<vector<int> > edges(m); //created vec of vec to hold edges (#rows = m)


	for (int i = 0; i < m; i++)
	{
		int x, y, wt; cin >> x >> y >> wt;
		//x--, y--; //Input is 1 based index convert it to 0 based indexing
		edges[i] = {wt, x, y}; //Minimum weight Spanning tree //helpful to sort on weight (#col = 3)
		//Vector of vector //Row->Column//3 Column in each row {} is one single element
	}

	sort(edges.begin(), edges.end() ); //By default sorted on first parameter

	DSU g;
	g.init(n); //index 0 to (n-1) //0 based INDEX

	for (int i = 0; i < m; i++)
	{
		int x = edges[i][1]; //1st edges -->srx node of edge
		int y = edges[i][2]; //1st edges -->des node of edge
		int z = edges[i][0]; //1st edges -->wt of edge

		//cout << z << " " << x + 1 << " " << y + 1 << endl;

		g.union_compo(x, y, z);
	}




	return 0;
}