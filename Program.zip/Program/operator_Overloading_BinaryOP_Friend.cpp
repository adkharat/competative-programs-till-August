#include <bits/c++config.h>
#include <iostream>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>


using namespace std;

class complex {

private:
    int real, img;
public:

    complex(int r = 0, int i = 0) {
        real = r;
        img = i;
    }



    void display() {
        cout << "real " << real << " img=" << img << endl;
    }

    friend complex operator + (complex, complex);


};


complex operator + (complex c1, complex c2) {
    complex c3;
    c3.real = c1.real + c2.real;
    c3.img = c1.img + c2.img;
    return c3;
}



int main() {
    complex c1(10, 2);
    complex c2(4, 5);
    c1.display();
    c2.display();

    complex c3 = c1 + c2;

    c3.display();
    // complex c3 = c1 + c2;

    return 0;
}