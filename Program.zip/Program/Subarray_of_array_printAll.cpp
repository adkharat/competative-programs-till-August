#include<iostream>
#include<bits/stdc++.h>

using namespace std;

void printarray(int arr[], int s, int e)
{
	int sum = 0;
	cout << "{ ";
	for (int i = s; i <= e; i++) {
		sum += arr[i];
		cout << arr[i] << " ";
	}
	cout << "}";

	cout << "SUM=" << sum << endl;

}

int main()
{

	int arr[] = {1, 2, 3, 4, 5};

	int n = sizeof(arr) / sizeof(arr[0]);

	cout << "array size is " << n << endl;

	for (int s = 0; s < n; s++)
	{
		for (int e = s; e < n; e++)
		{
			//cout << "i ->" << s << "j ->" << e << endl;
			printarray(arr, s, e);
		}

	}

	return 0;
}

