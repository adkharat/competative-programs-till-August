#include <iostream>
#include <bits/stdc++.h>

using namespace std;

void printsubseq(string subseq_arr, int css_idx) {
	cout << "{ ";
	for (int i = 0; i < css_idx; i++)
		cout << subseq_arr[i] << " ";
	cout << "}";

	cout << endl;

}

void generate_subseq(string arr, int n, int curr_idx, string subseq_arr, int  s_arr_idx) {

	if (curr_idx >= n) {

		printsubseq(subseq_arr, s_arr_idx);
		return;
	}

	subseq_arr[s_arr_idx] = arr[curr_idx];							//subseq_arr array Hold one subseq at a time.
	cout << subseq_arr[s_arr_idx] << " " << arr[curr_idx];
	generate_subseq(arr, n, curr_idx + 1, subseq_arr, s_arr_idx + 1); //Include the current elemet from array to subseq array.
	generate_subseq(arr, n, curr_idx + 1, subseq_arr, s_arr_idx);   //Exclude the current elemet from array to subseq array.

}

int main()
{

	string input = "ajay";
	int n = input.length();

	cout << "Sizze is" << n << endl;
	cout << "chara are " << input[0] << " " << input[3] << endl;

	string subseq_arr;

	generate_subseq(input, n, 0, subseq_arr, 0);

	for (int i = 0; i < input.length(); i++) {
		cout << input[i] << " --";
		cout << endl;
	}

	return 0;
}