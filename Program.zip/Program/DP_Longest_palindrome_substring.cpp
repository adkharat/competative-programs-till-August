#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int lpstr(string s) {

	int n = s.size();
	int max_len = 0;

	int DP[n][n];
	// All substrings of length are palindromes
	for (int i = 0; i < n; i++)
		DP[i][i] = 1;

	// check for sub-string of length 2.
	for (int i = 0; i < n - 1; i++)
		if (s[i] == s[i + 1])
			DP[i][i + 1] = 1;

	max_len = 2;

	// Check for lengths greater than 2
	for (int curr = 3; curr <= n; curr++) {
		// Fix the starting index
		for (int i = 0; i < n - curr + 1; i++) {
			// Get the ending index of substring from starting index i and length curr
			int j = i + curr - 1;
			if (s[i] == s[j] and DP[i + 1][j - 1]) { //boundary element are palindrome and non-boundary element are also palindrome
				DP[i][j] = 1;

				max_len = max(max_len, curr);
			}
		}

	}

	return max_len;
}

int main() {

	int t; cin >> t;
	while (t--) {
		string s; cin >> s;

		cout << "Longest Palindrome Substring " << lpstr(s);


	}

	return 0;
}