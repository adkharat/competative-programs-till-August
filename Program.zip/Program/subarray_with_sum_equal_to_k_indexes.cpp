#include<iostream>
#include<bits/stdc++.h>

using namespace std;
//Not SLIDING Window of size K
//1. Max no. -->Deque (2) MAx sum --> add [i] and sub [i-k]

//left and right pointer approch O(n) time complexity
//If sum is less -->increase right pointer
//If sum exceed then --> increment left with sub that array item.
//This is working only for positive no.
int subarray_k_sum(int *arr, int n, int sum)
{
	int curr_sum = 0;
	int l, r; l = r = 0;
	cout << "hi" << l << " " << r << endl;
	for (int i = 0; i < n; ++i)
	{
		while (curr_sum > sum and l < r) //If current become greater decrease it
		{
			curr_sum -= arr[l];
			l++;
		}
		if (curr_sum == sum) {
			cout << "Found " << l << " " << r - 1 << endl;
			return 1;
		}
		if (r < n) {	//If current sum is  not equal then increment R
			curr_sum += arr[r];
			r++;
			cout << curr_sum << " " << r << endl;
		}
	}

	return 0;
}

int main()
{
	int n; cin >> n;
	int sum; cin >> sum;
	int *arr = new int [n];

	for (int i = 0; i < n; i++) {
		cin >> arr[i];
	}

	if (subarray_k_sum(arr, n, sum))
		;
	else
		cout << "Not found" << endl;


	return 0;
}