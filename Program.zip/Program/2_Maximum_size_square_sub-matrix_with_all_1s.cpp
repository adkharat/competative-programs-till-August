#include <iostream>
#include<bits/stdc++.h>

using namespace std;
#define M 1000
const int N = 1000;

void fillArray(int array[][N], int row, int col)
{
	int i, j;
	cout << "Enter Data in array" << endl;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			cout << "Enter element [" << i << "][" << j << "]: " << col << " ";
			cin >> array[i][j];

		}
	}
}

void showArray(int array[][N], int row, int col)
{
	int i, j;
	cout << "Table of contents" << endl;
	for (i = 0; i < row; i++)
	{
		for (j = 0; j < col; j++)
		{
			cout << setw(3) << array[i][j]; //show row in one line
		}
		cout << endl;
	}
}

// Dynamic Memory Allocation in C++ for 2D Array
int main()
{
	int m, n;
	cin >> m >> n;

	int arr[m][N];

	fillArray(arr, m, n);
	showArray(arr, m, n);

	//Find maximum size square sub-matrix

	int temp[m][N] = {0};
	showArray(temp, m, n);
	int max_size = 0;

	for (int i = 0; i < m; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (i == 0 or j == 0)
				temp[i][j] = arr[i][j];
			else if (arr[i][j] == 0)
				temp[i][j] = 0;
			else
				temp[i][j] = min(min(temp[i - 1][j], temp[i - 1][j - 1]), temp[i][j - 1]) + 1;

			max_size = max(max_size, temp[i][j]);
			cout << i << " " << j << endl;
		}
	}

	cout << "Maximum size square submatrix " << max_size << endl;

	/*	// deallocate memory using delete[] operator
		for (int i = 0; i < m; i++)
			delete[] arr[i];

		delete[] arr;*/
	showArray(temp, m, n);



	return 0;
}