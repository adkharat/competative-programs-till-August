#include<iostream>
#include<bits/stdc++.h>

using namespace std;

vector<int> subsetA(vector<int> arr) {

	sort(arr.begin(), arr.end());

	int sum = 0, Asum = 0;
	for (auto x : arr)
		sum += x;

	//Last index
	int j = arr.size() - 1;
	//Array A sum
	vector<int> A; A.push_back(arr[j]);
	Asum += arr[j];
	sum -= arr[j];
	j--;

	//continue this until sum>=Asum
	while (j >= 0 && sum >= Asum) {
		A.push_back(arr[j]);
		Asum += arr[j];
		sum -= arr[j];
		j--;
	}
	sort(A.begin(), A.end());

	return A;
}


int main() {

	int n;
	cin >> n;
	vector<int> v;
	for (int i = 0; i < n; i++)
	{
		int k;
		cin >> k;
		v.push_back(k);
	}
	vector<int> x = subsetA(v);
	for (int i = 0; i < x.size(); i++)
	{
		cout << x[i] << " ";
	}


	return 0;
}