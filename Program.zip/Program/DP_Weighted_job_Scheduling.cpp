#include<iostream>
#include<bits/stdc++.h>

using namespace std;

class job
{
public:
	int start, end, profit;
};

bool JOBcomparater(job j1, job j2) {
	return j1.profit < j2.profit;
}

int findMaxProfit(job arr[], int n) {

	//Sort JOB based on finishing time
	sort(arr, arr + n, JOBcomparater);


	//1-D array to store result
	int *DP = new int[n];

	//If only 1 element in pipeline then max profit with that ele is that ele profit itself
	for (int i = 0; i < n; i++)
		DP[i] = arr[i].profit;

	//int max_profit = INT_MIN;
	for (int i = 1; i < n; i++) {
		for (int j = 0; j < i; j++) {
			//Check if both J and i job are compatable
			if (arr[j].end <= arr[i].start) {
				int curr_profit = arr[j].profit + arr[i].profit;
				DP[i] = max(DP[i], curr_profit);
			}



		}
	}

	return DP[n - 1];
}

int main()
{
	int t; cin >> t;

	while (t--) {
		int n; cin >> n;
		job arr[n];
		for (int i = 0; i < n; i++) {
			int s; cin >> s;
			int e; cin >> e;
			int p; cin >> p;
			arr[i] = {s, e, p};

		}
		cout << "The optimal profit is " << findMaxProfit(arr, n);
	}

	return 0;
}


// 1
// 4
// 3 10 20
// 1 2 50
// 6 19 100
// 2 100 200