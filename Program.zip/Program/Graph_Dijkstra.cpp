#include<iostream>
#include<bits/stdc++.h>

using namespace std;
template <typename T>
class Graph
{

	map<T, list<pair<T, int>>> l;
	int V;

public:

	Graph(int n) {
		this->V = n;
	}

	void addedge(T x, T y, int wt) {
		l[x].push_back(make_pair(y, wt));
		l[y].push_back(make_pair(x, wt));
	}

	void printAdjlist() {
		for (auto x : l) {
			T key = x.first;
			list<pair<T, int>> value = x.second;
			cout << "Vertex " << key << "-->  ";
			for (auto nbrs : value) {
				T node = nbrs.first;
				int wt = nbrs.second;
				cout << "(" << node << "," << wt << ")" << " ";
			}
			cout << endl;
		}
	}


	int getmini(int dist[], bool VertexSet[]) {
		int mini = INT_MAX;
		int mini_index;

		for (int v = 0; v < V; v++) {
			if (!VertexSet[v] and dist[v] <= mini ) {
				mini = dist[v];
				mini_index = v;
			}

		}

		return mini_index;
	}

	void dijkstra(int src) {

		int dist[V];
		bool VertexSet[V];
		for (int v = 0; v < V; v++) {
			dist[v] = INT_MAX;
			VertexSet[v] = false; //How many of them are finalize
		}

		dist[src] = 0;

		for (int i = 0; i < V - 1; i++) {

			int u = getmini(dist, VertexSet); //return index of next mini weight node
			cout << endl << "processed " << u  << " vertex " << endl;
			VertexSet[u] = true; //Finalise Vertex U in set;

			//Explore it nbrs
			for (auto x : l[u]) { //v is nbrs
				T nbr = x.first;
				int cost = x.second;
				if (VertexSet[nbr] == false and dist[u] + cost < dist[nbr] ) //neighbour not visited
					dist[nbr] = dist[u] + cost;

			}
		}

		//Print Distance of every vertex from src vertex
		for (int v = 0; v < V; v++)
			cout << dist[v] << " ";
	}

};

int main() {

	int n, e; cin >> n >> e;
	Graph<int> g(n);

	for (int i = 0; i < e; i++) {
		int x, y, wt; cin >> x >> y >> wt;
		g.addedge(x, y, wt);
	}

	g.printAdjlist();
	int src; cin >> src;
	g.dijkstra(src);


	return 0;
}