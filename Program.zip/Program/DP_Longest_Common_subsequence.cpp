#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int lcs(string s1, string s2) {
	int m = s1.length();
	int n = s2.length();
	int DP[m + 1][n + 1];
	for (int i = 0; i <= m; i++) {
		for (int j = 0; j <= n; j++) {
			if (i == 0 || j == 0)
				DP[i][j] = 0;
			else if (s1[i] == s2[j])
				DP[i][j] = 1 + DP[i - 1][j - 1];
			else
				DP[i][j] = max(DP[i][j - 1], DP[i - 1][j]);
		}
	}

	return DP[m][n];
}

int main() {

	int t; cin >> t;
	while (t--) {
		string s1; cin >> s1;
		string s2; cin >> s2;

		cout << "Longest palindrome Subsequence " << lcs(s1, s2);

	}

	return 0;
}