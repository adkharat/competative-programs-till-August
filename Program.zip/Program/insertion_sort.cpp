#include<iostream>

#include<bits/stdc++.h>

using  namespace std;

void insertion_sort(int arr[], int n) {

	int key, j;

	for (int i = 1; i < n; i++) {

		key = arr[i];
		j = i - 1;
		while (j >= 0 && arr[j] > key) {
			arr[j + 1] = arr[j];
			j = j - 1;
		}
		arr[j + 1] = key;
	}



}



int main()
{

	int arr[20] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
	cout << endl << "before sort" << endl;
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << " ";
	}
	cout << endl << "After Sort" << endl;

	insertion_sort(arr, 10);
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << " ";
	}

	return 0;
}