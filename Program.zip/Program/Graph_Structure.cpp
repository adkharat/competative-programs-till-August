#include <bits/stdc++.h>
using namespace std;

/*
//Array of list - (Adj list) runtime
class Graph1
{
	int V;
	//list<int> l[V]; But compile time we don't know the no. of Vertices. so go for dynamic creation
	list<int> *l;
public:
	Graph1(int V) {
		this->V = V;
		l = new list<int>[V];
	}

//Add edges in Graph
	void addEdge(int x, int y) {//edge between "X" and  "Y" bidirectional
		l[x].push_back(y);
		l[y].push_back(x);
	}
//Print Graph means print AdjList

	void printAdjList()
	{
		for (int i = 0; i < V; i++) //Vertical "V" vertices and in each Vertex print list
		{
			cout << "Vertex " << i << "--> ";
			for (auto x : l[i])
				cout << x << ",";
			cout << endl;
		}

	}//Print Graph end


};//class End

int main() {
	Graph1 g(4);
	g.addEdge(0, 1);
	g.addEdge(1, 2);
	g.addEdge(2, 3);
	g.addEdge(3, 0);
	g.addEdge(0, 2);
	g.addEdge(1, 3);

	g.printAdjList();

	return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

*/
//Main Goal is Adj list
//This structure(HashMap) is used when graph node are not integer or edges have Weight
//Default structure of Hash map is array. so no need to create array of Hashmap
/*
class Graph2
{
	map<string, list<pair<string, int>> > l;
public:

	void addEdge(string x, string y, int wt) {
		//l[x] will give me value for key which is LIST
		l[x].push_back(make_pair(y, wt));
		l[y].push_back(make_pair(x, wt));
	}
//Print Graph/Hashmap
	void printAdjList() {
		for (auto x : l) {
			string src = x.first;
			list<pair<string, int >> nbrs = x.second;
			cout << "Vertex " << src << "--> ";
			for (auto nbr : nbrs) {
				cout << "(" << nbr.first << "," << nbr.second << ") ";
			}
			cout << endl;
		}
	}

};

int main() {

	Graph2 g;

	g.addEdge("A", "B", 20);
	g.addEdge("B", "D", 40);
	g.addEdge("C", "D", 30);
	g.addEdge("A", "C", 10);
	g.addEdge("A", "D", 50);

	g.printAdjList();

	return 0;
}
*/
/////////////////////////////////////////////////////////////////////////////////
//Global Declaration
vector<vi> adj;//When Size is not known


////////////////////////////////////////////////////////////
#define not
vector<int> gr[N];//When Size is known



////////////////////////////////////////////////////////////////