
#include<bits/stdc++.h>
using namespace std;
void plusOne(vector<int> &A) {

	int n = A.size();
	int carry = 0;
	A[n - 1] += 1;
	carry = A[n - 1] / 10;
	A[n - 1] = A[n - 1] % 10;

	for (int i = n - 2; i >= 0; i--) {
		if (carry == 1) {
			A[i] += 1;
			carry = A[i] / 10;
			A[i] = A[i] % 10;
		}
	}

	if (carry == 1)
		A.insert(A.begin(), 1);
	// int count = 1;
	// for (auto it = A.begin(); it != A.end(); it++) {
	// 	cout << "Begin value is " << *it << endl;
	// 	cout << " count " << count++ << " ";
	// 	if (*(it) == 0) {
	// 		cout << *it << " ";
	// 		A.erase(it);
	// 	}
	// 	else {
	// 		cout  << "Break value is " << *it << " ";
	// 		break;
	// 	}

	// }
	// cout << endl << "done";
//Erase leading zero //V.fron() == value and V.begin()==address
	while (*(A.begin()) == 0 && A.size() > 1) {
		A.erase(A.begin());
	}
//Erase trailing zeros
	// while (ans[ans.size() - 1] == 0 && ans.size() > 1) {
	// 	ans.pop_back();
	// }

	//return A;
}

int main()
{
	vector<int> vect{0, 6, 0, 6, 4, 8, 8, 1};

	plusOne(vect);

	for (int i = 0; i < vect.size(); i++)
		cout << vect[i] << " ";

	return 0;
}