

#include <bits/stdc++.h>
using namespace std;

struct ListNode {
	int val;
	ListNode *next;
	ListNode() : val(0), next(nullptr) {}
	ListNode(int x) : val(x), next(nullptr) {}
	ListNode(int x, ListNode *next) : val(x), next(next) {}
};

void printlist(ListNode* head)
{
	while (head != NULL) {
		cout << head->val << " ";
		if (head->next)
			cout << "-> ";
		head = head->next;
	}
	cout << endl;
}


ListNode* getnode(int key) {
	ListNode* temp = new ListNode;
	temp->val = key;
	temp->next = NULL;

	return temp;
}

ListNode*  getmiddle(ListNode* head) {
	ListNode *slow, *fast;
	slow = fast = head;
	while (fast->next != NULL and fast->next->next != NULL) {
		slow = slow->next;
		fast = fast->next->next;
	}

	return slow;
}

void reverselist(ListNode **head2) {

	ListNode *prev = NULL, *curr = *head2, *ahead;

	while (curr != NULL) {
		ahead = curr->next;
		curr->next = prev;
		prev = curr;
		curr = ahead;
	}

	*head2 = prev;
}

void reorderList(ListNode* head) {

	if (head == NULL || head->next == NULL || head->next->next == NULL) //0 length || 1 length || 2 length //cannpt be reorder
		return ;

	ListNode *middle = getmiddle(head); cout << "Middle elemenet is " << middle->val << endl;
	ListNode *head1 = head; cout << "List1 start at " << head1->val << endl;
	ListNode *head2 = middle->next;  cout << "List2 start at " << head2->val << endl;
	middle->next = NULL;

	cout << "List 2 Before reverse "; printlist(head2); cout << endl;
	reverselist(&head2);//Reverse list2
	cout << "List 2 after reverse "; printlist(head2); cout << endl;

	//create dummy node
	head = getnode(0);
	ListNode *curr = head; //curr node pointing to dummy node

	while (head1 != NULL || head2 != NULL) {

		if (head1 != NULL) {
			curr->next = head1;
			curr = curr->next;
			head1 = head1->next;
		}

		if (head2 != NULL) {
			curr->next = head2;
			curr = curr->next;
			head2 = head2->next;
		}
	}

	head = head->next; //leave dummy node

}



// Driver program
int main()
{
	ListNode* head = getnode(1);
	head->next = getnode(2);
	head->next->next = getnode(3);
	head->next->next->next = getnode(4);
	head->next->next->next->next = getnode(5);

	printlist(head); // Print original list
	reorderList(head); // Modify the list
	printlist(head); // Print modified list
	return 0;
}