#include<bits/stdc++.h>
using namespace std;
#define vi vector<int>
#define pb push_back

int sumPossible = 0;

int isSubsetSum(vi arr, int sum) {
	int n = arr.size();

	vector<vi> DP(n + 1, vector<int>(sum + 1, 0));
	cout << "DP array isze is " << DP.size() << endl;

	for (int i = 0; i < n; i++)
		cout << arr[i] << " ";
	cout << endl << "Sum is " << sum << endl;;

	for (int j = 0; j <= sum; j++)
		DP[0][j] = false;
	for (int i = 0; i <= n; i++)
		DP[i][0] = true;

	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= sum; j++) {
			if (j < arr[i - 1]) //input array item is larger than expexted target sum then ignore it
				DP[i][j] = DP[i - 1][j];
			else if (j >= arr[i - 1])
				DP[i][j] = DP[i - 1][j] || DP[i - 1][j - arr[i - 1]];
		}
	}
	cout << "Done" << endl;
	//return DP[n][sum];

	for (int j = 0; j <= sum; j++)
		cout << setw(2) << setfill(' ') << j << " ";
	cout << endl;


	for (int i = 0; i <= n; i++) {
		for (int j = 0; j <= sum; j++)
			cout << setw(2) << setfill(' ') << DP[i][j] << " ";
		cout << endl;
	}

	for (int j = sum; j >= 0; j--) {
		if (DP[n][j]) {
			sumPossible = j;
			cout << j << " Finsih " << endl;
			break;
		}
	}
	cout << "Go back " << endl;
	return sumPossible;
}

int main() {
	int t; cin >> t;
	while (t--) {
		int n; cin >> n;
		vi arr(n);
		arr.clear();
		int sum = 0;
		for (int i = 0; i < n; i++) {
			int x; cin >> x;
			sum += x;
			arr.pb(x);
		}
		//sort(arr.begin(), arr.end());
		int result = isSubsetSum(arr, sum / 2);
		cout << "ajay " << endl;
		if (result) {

			cout << "First Subarray Sum is " << result << endl;
			cout << "Second Subarray" << abs(sum - result) << endl;
			cout << "Minimum Difference is " << abs(abs(sum - result) - result) << endl;
		}

	}

	return 0;
}