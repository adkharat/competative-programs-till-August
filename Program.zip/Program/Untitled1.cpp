#include<iostream>
#include<algorithm>
#include<string>

using namespace std;

bool cmp(long long a, long long b)
{
    cout<<"comparing "<<a<<" and "<<b<<endl;
    if(a==1)
    return false;
    else
    return true;

    //return a<b;

}

int main()
{


    //string s2;
   // string tmp;
    int n; cin>>n;
    long long s[n];
    //cin.get();

    for(int i=0;i<n;i++)
    {
        cin>>s[i];
    }


    sort(s,s+n,cmp);

    for(int i=0;i<n;i++)
        cout<<s[i]<<endl;

    return 0;

}
