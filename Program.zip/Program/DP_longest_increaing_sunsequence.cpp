#include<iostream>
#include<bits/stdc++.h>

using namespace std;

//Longest Increaing subsequence

int LIS(int arr[], int n) {

	int DP[n] = {1};

	for (int i = 1; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (arr[j] < arr[i] and DP[j] + 1 > DP[i])
				DP[i] = DP[j] + 1;
		}
	}

	return *max_element(DP, DP + n);
}


int main() {

	int arr[] = {10, 3, 50, 12, 25, 80, 90};

	int n = sizeof(arr) / sizeof(arr[0]);

	cout << "Longest Increaing subsequence " << LIS(arr, n);


	return 0;
}