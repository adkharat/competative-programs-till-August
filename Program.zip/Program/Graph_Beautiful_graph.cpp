#include <bits/stdc++.h>
using namespace std;

#define vi vector<int>
#define pb push_back
#define w(t) int t;cin>>t; while(t--)
#define FIO ios_base::sync_with_stdio(false); cin.tie(NULL);

vector<vi> adj;
int cnt0 = 0, cnt1 = 0, ODD_Cycle = 0;

//0 for even parityu and 2 for ODD color
void dfs(int src, vi &visited, int parity = 0) {


	if (visited[src]) {
		if (1 + parity != visited[src])
			ODD_Cycle = 1;
		return;
	}

	if (parity == 0) //Even parity
		cnt0++, visited[src] = 1;
	else	//ODD parity
		cnt1++, visited[src] = 2;

	for (auto nbr : adj[src]) {
		dfs(nbr, visited, 1 - parity);
	}

}

int get() {
	int ans = 1;

	vi visited(n + 1, 0);

	for (int i = 1; i <= n; i++) {
		if (!visited[i])
		{
			//For every component
			cnt0 = 0, cnt1 = 0, ODD_Cycle = 1;
			dfs(1, visited);

			if (ODD_Cycle)
				return 0;//ODD length cycle is present

			ans = (ans * (pow(2, cnt0) + pow(2, cnt1))) % 998244353;

		}

	}

	return ans;
}

int main() {

	FIO
	w(t) {
		int n, m; cin >> n >> m;
		adj.clear();
		adj.resize(n + 1);
		while (m--) {
			int u, v; cin >> u >> v;
			adj[u].pb(v);
			adj[v].pb(u);
		}
		cout << get() << "\n";
	}

	return 0;
}