#include<iostream>
#include<bits/stdc++.h>

using namespace std;


class Graph
{
	int V;
	vector<pair<int, int>> *v;

public:
	Graph(int vec)
	{
		this->V = vec;
		v = new vector<pair<int, int>>[V];
	}

	void addedge(int src, int dest, int wt)
	{

		v[src].push_back(make_pair(dest, wt));
		v[dest].push_back(make_pair(src, wt));

	}

	void printadjlist()
	{

		for (int i = 1; i < V; i++) {
			cout << i << " -->";
			for (auto nbr : v[i])
			{
				cout << "(" << nbr.first << " ," << nbr.second << ")";
			}
			cout << endl;
		}

	}

	int getminimum(int *distance, bool *flag)
	{
		int min = INT_MAX, index = 1;

		for (int i = 1; i <= V; i++)
		{
			//if a node is a relaxed node
			if (flag[i] == false and distance[i] <= min) //From unfinalizes node select one with minimum distance
			{
				min = distance[i];
				index = i;
			}
		}
		cout << endl << index << "  " << distance[index] << " ";
		return index; //return the index of node which is unfinalized and with minii distance
	}


	void dijkstra(int src)
	{

		int *distance = new int[V]; //hold shortest distance of every node from source node.
		bool *flag = new bool[V]; //hold status of every node whether a node is finalized or not.


		for (int i = 1; i <= V; i++) {
			distance[i] = INT_MAX;
			flag[i] = false;
		}

		for (int i = 1; i <= V; i++) {
			cout << distance[i] << " " << flag[i] << " ";
		}

		distance[src] = 0;

		for (int i = 1; i <= V - 1 ; i++) {
			int min = getminimum(distance, flag); //From set of relaxed node get node which is unfinalized from + has minimum distance //Visulize it from 2nd node and not source
			cout << min << endl;
			//Now finalized this node
			flag[min] = true;

			//Relax all outgoing edges(neighbours i.e v[min][i]) of this min index node
			//Initially src = min node
			for (auto nbrs : v[min]) {
				int node = nbrs.first;
				int dist = nbrs.second;
				cout << node << " " << dist << endl;
				if (!flag[node] and distance[min] != INT_MAX and dist and distance[min] + dist < distance[node]) {
					distance[node] = distance[min]  + dist;
					cout << node << " " << distance[node] << endl;
				}

			}
		}


		for (int i = 1; i <= V - 1; i++)
			cout << "Node " << i << " " << "--> " << distance[i] << endl;

	}


};

int main()
{
	Graph g(5);

	g.addedge(1, 2, 1);
	g.addedge(1, 3, 4);
	g.addedge(1, 4, 7);
	g.addedge(2, 3, 1);
	g.addedge(3, 4, 2);


	g.printadjlist();

	g.dijkstra(1);

	return 0;
}