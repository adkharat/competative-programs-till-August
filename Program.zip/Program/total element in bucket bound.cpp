#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
    int arr[] = {10,90,120,120,120,120,1000,1200}; //Sorted array`
    int n = sizeof(arr)/sizeof(int);

    int key;cin>>key;

    bool present = binary_search(arr,arr+n,key);

    if(present){
        auto lb = lower_bound(arr,arr+n,key);
        auto ub = upper_bound(arr,arr+n,key);
        cout<<"element present at: "<<(lb-arr)<<endl;
        cout<<"Total no of element are: "<<(ub-lb)<<endl;
    }
    else
        cout<<"element is not present";


    cout<<"Hello";
    return 0;
}
