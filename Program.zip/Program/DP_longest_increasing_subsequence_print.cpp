#include<iostream>
#include<bits/stdc++.h>

using namespace std;

// Utility function to print LIS
void PrintLIS(vector<int> v) {
	for (int x : v)
		cout << x << " ";
	cout << endl;
}

void constrcut_LIS(int arr[], int n) {
	//2-D array for LIS
	vector<vector<int>> L(n); //n- rows

	L[0].push_back(arr[0]); //Every element is LIS of length 1

	//start from 2nd element
	for (int i = 1; i < n; i++) {
		for (int j = 0; j < i; j++) {
			if (arr[j] < arr[i] and (L[i].size() < L[i].size() + 1))
				L[i] = L[j]; //If length of jth list is greater than current list then assign that list element to this list
		}
		L[i].push_back(arr[i]); //Make this element as part of LIS
	}

//Find longest length LIS
	vector<int> max = L[0]; //Initially let 1st list be LIS
	for (vector<int> v : L)
		if (max.size() < v.size())
			max = v;

	PrintLIS(max);
}


int main() {
	int arr[] = {3, 2, 6, 4, 5, 1 };
	int n = sizeof(arr) / sizeof(arr[0]);

	constrcut_LIS(arr, n);

	return 0;

}