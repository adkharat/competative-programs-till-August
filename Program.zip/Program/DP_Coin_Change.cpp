#include<iostream>
#include<bits/stdc++.h>

using namespace std;

/*Given a value N, if we want to make change for N cents, and
we have infinite supply of each of S = { S1, S2, .. , Sm} valued coins,
how many total ways can we make the change? The order of coins doesn’t matter.
*/


int count(int arr[], int n, int m) {

	cout << "SUM valued " << m << endl;

}



int main() {
	int coins[] = {1, 2, 5};
	int n = sizeof(coins) / sizeof(coins[0]);
	int m = 11;
	cout << "Mini coins needed " << count(coins, n, m);

	return 0;
}