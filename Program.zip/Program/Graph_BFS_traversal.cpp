#include <bits/stdc++.h>
using namespace std;


//BFS Traversal Itterative Version
//First Store Graph using link list
class Graph
{
	int V;
	list<int> *l;
public:
	Graph(int V) {
		this->V = V;
		l = new list<int>[V];
	}

	void addEdge(int x, int y) {
		l[x].push_back(y);
		l[y].push_back(x);
	}

	void printAdjlist() {
		for (int i = 0; i < V; i++) {
			cout << "Vertex " << i << "-->";
			for (auto x : l[i])
				cout << x << " ";
			cout << "\n";
		}
	}

	void BFS_traversal(int src) {

		bool *visited = new bool[V];
		for (int i = 0; i < V; i++)
			visited[i] = 0;

		queue<int> q;

		visited[src] = true;
		q.push(src);

		while (!q.empty()) {
			int s = q.front();
			cout << s << " ";

			q.pop();

			for (auto x : l[s]) {
				if (visited[x] == false) {
					q.push(x);
					visited[x] = true;
				}
			}
		}
	}
};

int main() {
	int n, e; cin >> n >> e;
	Graph g(n);

	while (e--) {
		int x, y; cin >> x >> y;
		g.addEdge(x, y);
	}

	g.printAdjlist();

	int src; cin >> src;
	g.BFS_traversal(src);


	return 0;
}