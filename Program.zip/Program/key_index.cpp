#include<iostream>

using namespace std;

int main()
{
    int arr[] = {10,9,20,28,4}
    int size = sizeof(arr)/sizeof(int);

    int key;cin>>key;

    auto it = find(arr,arr+n,key);

    index =  it - arr;

    if(it == (arr+n))
    cout<<"Key not present\n"
    else
    cout<<"Key Index = "<<index<<endl;
    cout<<"Hello";
    return 0;
}
