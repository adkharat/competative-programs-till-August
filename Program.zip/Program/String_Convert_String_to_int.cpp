#include <bits/stdc++.h>
using namespace std;

int my_atoi(string s) {

	if (s == "\0")
		return 0;
	int n = s.size();
	cout << "String size is " << n << endl;
	int result = 0;
	int sign = 1;
	int i = 0;
	if (s[0] == '-') {
		sign = -1;
		i++;
	}
	for ( ; i < n ; i++) {

		if (s[i] - '0' == 0 || 1 || 2 || 3 || 4 || 5 || 6 || 7 || 8 || 9) {
			cout << s[i] << " ";
			result = result * 10 + (s[i] - '0');
			cout << "Result is " << result << endl;
		}
		else {
			return 0;
			cout << "Welcome" << endl;
		}
	}

	return result * sign;
}

int main()
{
	int t; cin >> t;
	while (t--) {
		string s; cin >> s;
		int con = my_atoi(s);
		if (con )
			cout << "Given input string is Integer " << con << endl;
		else
			cout << "Input string is not Integer " << endl;
	}

	return 0;
}