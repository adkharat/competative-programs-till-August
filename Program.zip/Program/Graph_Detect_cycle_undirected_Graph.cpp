#include <bits/stdc++.h>
using namespace std;

class Graph {
	int V;
	list<int> *l;

public:

	Graph(int v) {
		this->V = v;
		l = new list<int>[V];
	}

	void addedge(int x, int y) {
		l[x].push_back(y);
		l[y].push_back(x);
	}

	void printadjlist() {
		for (int i = 0; i < V; i++) {
			cout << "Vertex " << i << "--> ";
			for (auto x : l[i])
				cout << x << " ";
			cout << endl;
		}
	}

	bool dfs_utility(int src, bool *visited, int parent ) {

		visited[src] = true;

		for (auto nbr : l[src]) {
			if (!visited[nbr])
			{
				if (dfs_utility(nbr, visited, src))
					return true;
			}
			else if (visited[nbr] and nbr != parent)
				return true;

		}

		return false;

	}

	bool detect_cycle() {
		bool *visited = new bool[V];

		for (int i = 0; i < V; i++)
			visited[i] = false;

		if (dfs_utility(0, visited, -1))
			return true;

		return false;
	}


};

int main() {


	int n, e; cin >> n >> e;
	Graph g(n);

	for (int i = 0; i < e; i++) {
		int x, y; cin >> x >> y;
		g.addedge(x, y);
	}

	g.detect_cycle() ? cout << "Cycle is present \n " : cout << "Cycle Not present \n";

	return 0;

}