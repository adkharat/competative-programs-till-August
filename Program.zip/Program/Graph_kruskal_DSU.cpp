#include<iostream>
#include<bits/stdc++.h>
#define pb push_back

using namespace std;

class DSU {

	vector<int> parent; //To hold super parent of every element
	int total_comp; //Initially for all N vertices we call them as independent component

public:

	//Initially parent of every node is itself only
	void init(int n) {
		parent.clear(); parent.resize(n);

		//iota(parent.begin(), parent.end(), 0);
		for (int i = 0; i < n; i++) {
			parent[i] = i;
		}
		total_comp = n;
	}

	int get_superparent(int x) {
		if (parent[x] == x)return x;
		else return parent[x] = get_superparent(parent[x]);
	}

	//Merge/union of disjoint component
	void union_compo(int x, int y) {
		int superParent_x = get_superparent(x);
		int superParent_y = get_superparent(y);
		if (superParent_x != superParent_y) {
			parent[superParent_x] = superParent_y;
			total_comp--;
		}
		else
			cout << "Cycle exist " << endl;
	}

	void printComp(int n) {
		cout << "Total Component after union " << total_comp << endl;

		for (int i = 0; i < n; i++) cout << parent[i] + 1 << " ";
		cout << endl;

	}



};

void solve() {

	int n, m; cin >> n >> m;
	//To store edges{x,y,wt} use 2D-Array
	//We have m edges 0,1,2,...m. At each index store one edge;
	vector<vector<int>> edges(m); //To store weighted edges so we can sorted based on weight

	DSU g;

	g.init(n);//index 0 to (n-1) //0 based INDEX

	//Take input this edges
	for (int i = 0; i < m; i++) {
		int x, y, wt; cin >> x >> y >> wt; //Get input in 1 based indexing
		x--; y--; //Convert back to 0 based indexing
		edges[i] = {wt, x, y}; //store 3 Columns at each row index
	}

	sort(edges.begin(), edges.end());

	int ans = 0;
	for (int i = 0; i < m; i++)
	{
		int x = edges[i][1]; //1st edges -->srx node of edge
		int y = edges[i][2]; //1st edges -->des node of edge
		int wt = edges[i][0]; //1st edges -->wt of edge

		//cout << z << " " << x + 1 << " " << y + 1 << endl;
		if (g.get_superparent(x) != g.get_superparent(y)) {
			//Can take this path
			g.union_compo(x, y);//Include all sorted edges that doesn't result in a cycle
			cout << "(" << wt << " " << x << " " << y << ")" << endl;
			ans += wt;
		}
	}


	cout << "Mini Spanning tree cost using Kruskal algo " << ans << endl;

	g.printComp(n);
}

int main() {

	solve();

	return 0;
}

/*
9 15
1 2 10
2 4 8
4 7 8
7 9 2
8 9 11
6 8 6
3 6 1
1 3 12
2 3 9
3 5 3
4 5 7
5 6 3
4 6 10
4 8 5
7 8 9
*/