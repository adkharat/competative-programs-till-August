#include<iostream>
#include<climits>
#include<cmath>
#include<cstring>
#include<cstdlib>

using namespace std;
#define ll long long int
const int  NROW = 400;
const int  NCOL = 300;

int arr1[10000];

//C style String = char array
void getstring1(char str[]) {

	cout << str << endl;
}

void getstring2(char *str) {

	cout << str << endl;
}


//C++ style String Class
void getstring3(string str) {

	cout << str << endl;
	string rev = str;

	for (int i = 0; i < (rev.size() / 2); i++)
	{
		char temp = rev[i];
		rev[i] = rev[(rev.size() - i - 1)];
		rev[(rev.size() - i - 1)] = temp;

	}

	cout << "Original= " << str << " reverse = " << rev << endl;

}

//Pass by values
inline string concatr1(string s1, string s2) {
	return s1 = s1 + s2;
}

//Pass by reference
inline string concatr2(string &s1, string &s2) {
	return s1 = s1 + s2;
}

//Pass by reference with constant
inline string concatr3( string &s1, const string &s2) {
	return s1 = s1 + s2;
}


// overloading functions

int sum(int a, int b) {
	return a + b;
}

float sum(float a, float b) {

	return a + b;
}

template<typename T>
T sum(T a, T b) {
	cout << "\n Wecome to template\n";
	return a + b;
}

/*template<typename T, typename U>
void sum(T a, U b) {
	cout << "\n Wecome to template\n";
	cout << a << " " << b << endl;
}
*/
//PRINT 1D array
void printarray (int arg[], int length) {
	for (int n = 0; n < length; ++n)
		cout << arg[n] << ' ';
	cout << '\n';
}



//PRINT 2D array
void print(int arr[][NROW], int m, int n)
{
	int i, j;
	for (i = 0; i < m; i++)
		for (j = 0; j < n; j++)
			printf("%d ", arr[i][j]);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main()
{

	//int i1; cout << sizeof(i1) << endl;
	//short int i2; cout << sizeof(i2) << endl;
	//long int i3; cout << sizeof(i3) << endl;
	//long long int i4; cout << sizeof(i4) << endl;

	//signed char c1; cout << sizeof(c1) << endl;
	//unsigned char c2; cout << sizeof(c2) << endl;
	/*	cout << "LIMITS is " << INT_MAX << endl;
		cout << "LIMITS is " << INT_MIN << endl;
		cout << "LIMITS is " << CHAR_MAX << endl;
		cout << "LIMITS is " << CHAR_MIN << endl;
		cout << "LIMITS is " << SHRT_MAX << endl;
		cout << "LIMITS is " << SHRT_MIN << endl;*/

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//int arr2[10000];

	/*	for (int i = 0; i < 5; i++)
			cin >> arr1[i];

		for (int i = 0; i < 5; i++)
			cout << arr1[i] << endl;
	*/


//////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/*	char str1[] = "ajay"; //C-String
		char *str2 = "Ajay";
		string str3 = "Ajay"; //C++ String
		string str4 = "Kharat";
		string str5;


		cout << "C String length " << strlen(str1) << endl;
		cout << "c++ String length " << str3.length() << endl;

		//String copy
		str4 = str4;
		cout << "String after Copy " << str3 << endl;

		//String concatination
		str5 = str3 + str4;
		cout << "String after concatination " << str4 << endl;

		//string length or size
		cout << "Strin length " << str4.length() << " OR " << str4.size() << endl;

		getstring1(str1);
		getstring2(str1);
		getstring1(str2);
		getstring2(str2);
		getstring3(str3);
		getstring3(str1);
		getstring3(str2);*/

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	/*int arr[NROW][NCOL] = {0};

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 3; j++)
			cout << arr[i][j] << " ";
		cout << endl;
	}

	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 3; j++)
			arr[i][j] = j;
		cout << endl;
	}


	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 3; j++)
			cout << arr[i][j] << " ";
		cout << endl;
	}


	cout << "2-D array size " << sizeof(arr) << endl;
	*/

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/*	int i = 10;
		int *ptr = &i;
		cout << "variable " << i << " and its addrress " << ptr << " = " << &i << endl;
		cout << "size of " << sizeof(ptr) <<  endl;
		cout << "size of  " << sizeof(*ptr) << endl;

		char c = 'c';
		char *cptr = &c;
		cout << "variable " << c << " and its addrress " << cptr << " = " << &c << endl;
		cout << "size of " << sizeof(cptr) <<  endl;
		cout << "size of  " << sizeof(*cptr) << endl;
	*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	int rowCount = 3;
	int colCount = 4;


//C style 2D- Memory allocation

	//int **arr = (int **)malloc(rowCount * sizeof(int *));

	/*int *arr[rowCount];

	for (int i = 0; i < rowCount; i++)
		arr[i] = (int *)malloc(colCount * sizeof(int));


	for (int i = 0; i < rowCount; i++)
		for (int j = 0; j < colCount; j++)
			cin >> arr[i][j];

	for (int i = 0; i < rowCount; i++) {
		for (int j = 0; j < colCount; j++)
			cout << arr[i][j] << " ";
		cout << endl;
	}

	for (int i = 0; i < rowCount; i++)
		free(arr[i]);

	free(arr);


	cout << arr[1][2];*/

//C++ Style Memory allocation

	/*	int **arr = new int *[rowCount];

		for (int i = 0; i < rowCount; i++)
			arr[i] = new int[colCount];


		for (int i = 0; i < rowCount; i++)
			for (int j = 0; j < colCount; j++)
				cin >> arr[i][j];

		for (int i = 0; i < rowCount; i++) {
			for (int j = 0; j < colCount; j++)
				cout << arr[i][j] << " ";
			cout << endl;
		}


		for (int i = 0; i < rowCount; i++)
			delete[] arr[i];

		delete[] arr;

		arr =NULL;
		cout<<arr[1][2];

		*/
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	/*string s1 = "Ajay";
	string s2 = "Kharat";

	cout << concatr1(s1, s2) << endl;
	cout << s1 << " " << s2 << endl;

	cout << concatr2(s1, s2) << endl;
	cout << s1 << " " << s2 << endl;

	cout << concatr3(s1, s2) << endl;
	cout << s1 << " " << s2 << endl;
	*/

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Function overloading
	cout << sum(10, 20) << endl;
	cout << sum(10.5, 20.3) << endl;
	cout << sum<int>(10, 20) << endl;
	cout << sum<float>(10, 20) << endl;
	cout << sum<double>(10, 20) << endl;
	//sum<int, double>(10, 12.5);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//no longer need for the equal sign between the declaration and the initializer.
	//int fooo[] = { 10, 20, 30 };
	int fooo[] { 10, 20, 30 };
//The initializer can even have no values, just the braces:
	int baz [5] = { };


	/*Arrays as parameters
	--------------------------
	At some point, we may need to pass an array to a function as a parameter. In C++, it is not possible to pass the entire block of memory represented by an array to a function directly as an argument. But what can be passed instead is its address. In practice, this has almost the same effect, and it is a much faster and more efficient operation.

	To accept an array as parameter for a function, the parameters can be declared as the array type, but with empty brackets, omitting the actual size of the array. For example:
	void procedure (int arg[])
	*/
	int firstarray[] = {5, 10, 15};
	int secondarray[] = {2, 4, 6, 8, 10};
	printarray (firstarray, 3);
	printarray (secondarray, 5);

	for (int elem : firstarray)
		cout << elem << '\n';

	/*In a function declaration, it is also possible to include multidimensional arrays. The format for a tridimensional array parameter is:


	base_type[][depth][depth]


	For example, a function with a multidimensional array as argument could be:


	void procedure (int myarray[][3][4])


	Notice that the first brackets [] are left empty, while the following ones specify sizes for their respective dimensions. This is necessary in order for the compiler to be able to determine the depth of each additional dimension.
	*/
	int arr[][NROW] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};

	print(arr, 3, 3);

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//Plain arrays with null-terminated sequences of characters are the typical types used in the C language to represent strings (that is why they are also known as C-strings).

	/*By convention, the end of strings represented in character sequences is signaled by a special character:
	the null character, whose literal value can be written as '\0' (backslash, zero).

	string literals always have a null character ('\0') automatically appended at the end.s
	*/

	char myword[] = { 'H', 'e', 'l', 'l', 'o', '\0' };
	//char myword[] = "Hello";

	/*In both cases, the array of characters myword is declared with a size of 6 elements of type char: the 5 characters that compose the word "Hello", plus a final null character ('\0'), which specifies the end of the sequence
	and that, in the second case, when using double quotes (") it is appended automatically.
	*/


	/*In C++, even though the standard library defines a specific type for strings (class string), still, plain arrays with null-terminated sequences
	of characters (C-strings) are a natural way of representing strings in the language; in fact, string literals still always produce null-terminated character sequences, and not string objects.
	//strings have a dynamic size determined during runtime, while the size of arrays is determined on compilation, before the program runs.
	*/


	/*In any case, null - terminated character sequences and strings are easily transformed from one another:

		Null - terminated character sequences can be transformed into strings implicitly, and strings can be transformed into null - terminated character sequences by using either of string's member functions c_str or data:
	*/

	char myntcs[] = "Ajay Kharat";
	string mystring = myntcs;  // convert c-string to string
	cout << mystring;          // printed as a library string
	cout << mystring.c_str();  // printed as a c-string

	return 0;
}