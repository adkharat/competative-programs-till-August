#include <iostream>
using namespace std;
//ount the number of ways to reach a given score in a game using 1, 2 anf 6
int count(int n) {
	int DP[n / 2 + 1];

	DP[0] = 1;
	DP[1] = 1;
	DP[2] = 2;
	for (int i = 3; i <= n / 2; i++)
		DP[i] = DP[i - 1] + DP[i - 2] + DP[i - 3];

	return DP[n];
}


int main()
{
	cout << count(10) << endl;
	return 0;
}