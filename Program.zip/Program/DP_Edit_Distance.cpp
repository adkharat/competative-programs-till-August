#include<iostream>
#include<bits/stdc++.h>
/*Find minimum number of edits (operations) required to convert ‘str1’ into ‘str2’.

Insert
Remove
Replace
*/
using namespace std;
int editDist(string str1, string str2) {
	int m = str1.size();
	int n = str2.size();
	int DP[m + 1][n + 1];

	for (int i = 0; i <= m; i++) {
		for (int j = 0; j <= n; j++) {
			// If first string is empty, only option is to
			// insert all characters of second string
			if (i == 0 )
				DP[i][j] = j;
			// If second string is empty, only option is to
			// remove all characters of second string
			else if (j == 0)
				DP[i][j] = i;

			// If last characters are same, ignore last char
			// and recur for remaining string
			else if (str1[i - 1] == str2[j - 1])
				DP[i][j] = DP[i - 1][j - 1];
			// If the last character is different, consider all
			// possibilities and find the minimum
			else
				DP[i][j] = 1 + min(DP[i][j - 1], // Insert
				                   min(DP[i - 1][j], // Remove
				                       DP[i - 1][j - 1])); // Replace
		}
	}

	return DP[m][n];
}

int main()
{
	// your code goes here
	string str1 = "sunday";
	string str2 = "saturday";

	cout << editDist(str1, str2);

	return 0;
}