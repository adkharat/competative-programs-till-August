#include<bits/stdc++.h>

using namespace std;

int bin_search(int arr[], int n, int key)
{
	int start = 0;
	int end = n - 1;

	while (start <= end) //Successful search
	{
		int mid = (start + end) / 2;

		if (arr[mid] == key)
			return mid;
		else if (arr[mid] > key)
			end = end - 1;
		else
			start = start + 1;
	}

	return -1;	//Failed to search
}

int main()
{

	int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	int n = sizeof(arr) / sizeof(int);
	int key;	cin >> key;
	int res = bin_search(arr, n, key);
	if (res != -1)
		cout << "elemet  is present at " << res << endl;
	else
		cout << "elemet is not present";

	return 0;
}