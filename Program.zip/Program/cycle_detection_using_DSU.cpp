#include<iostream>
#include<bits/stdc++.h>

using namespace std;


class DSU
{

	vector<int> parent;
	int total_comp;

public:

	//Initially parent of every node is itself only
	void init(int nn)
	{
		parent.clear(); parent.resize(nn);
		iota(parent.begin(), parent.end(), 0);
		for (int i = 0; i < nn; i++)
			parent[i] = i;
		//If I want to get total component
		total_comp = nn;
	}

	//Get super_parent of a node using PATH compression O(1) time complexity
	int get_superparent(int x)
	{
		if (parent[x] == x)
			return x;
		else
			return parent[x] = get_superparent(parent[x]);

	}

	//Merge/union of disjoint component
	void union_compo(int x, int y) {

		int x_super = get_superparent(x);
		int y_super = get_superparent(y);

		if (x_super != y_super) {
			parent[x_super] = y_super;
			total_comp--; //after union total component reduces by 1 bcs of merging of 2 comp at a time
		}
		else {
			cout << "cycle in a graph";
		}

	}

	void printcomp()
	{
		cout << endl << "total Comp " << total_comp << endl;
	}



};


int main()
{

	DSU g;
	int n, m; cin >> n >> m;

	g.init(n); //index 0 to (n-1) //0 based INDEX

	for (int i = 0; i < m; i++)
	{
		int x, y; cin >> x >> y;
		x--; y--; // 1 based INDEX
		g.union_compo(x, y);
	}

	g.printcomp();

	return 0;
}