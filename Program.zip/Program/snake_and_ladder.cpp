#include<iostream>
#include<bits/stdc++.h>
using namespace std;

template<typename T>
class Graph
{

	map<T, list<T> > m;

public:

	void addedge(T src, T dest)
	{

		m[src].push_back(dest);
	}


	int bfs(T src, T dest)
	{

		queue<T> q;
		map<T, int> distance;
		map<T, T> parent;

		//Initially all distance is inifinity from source

		for (auto  node_pair : m)
		{
			T node = node_pair.first;
			distance[node]  = INT_MAX;
		}

		q.push(src);
		distance[src] = 0;
		parent[src] = src;	//Parent of source is source


		while (!q.empty())
		{
			int expl = q.front();
			q.pop();

			for (auto nbrs : m[expl])
			{
				if (distance[nbrs] == INT_MAX)
				{
					q.push(nbrs);
					distance[nbrs] = distance[expl] + 1; //Distance of nbrs node from parent --> parent distance in turn is shortest dist from source.
					parent[nbrs] = expl;
				}
			}
		}

		T temp = dest;
		while (temp != src) //BackTracking
		{
			cout << temp << "<--";
			temp = parent[temp];
		}
		cout << src << endl;
		/*		for (auto node_pair : m)
				{
					T node = node_pair.first;
					cout << node << " -->" << distance[node] << endl;
				}
		*/
		return distance[dest];
	}




};


//similar to single sourece shortest path problem
//Given 6 X 6 board
int main()
{

	//store jummp info of each board location
	int board[50] = {0};

	//ladder start at 2 and ends at 15 then board[2] = 15-2 =>13
	//snake mouth at 17 and tail at 4 then board[17] = 17 - 4 = -13
	board[2] = 13;
	board[5] = 2;
	board[9] = 18;
	board[18] = 11;
	board[17] =  -13;
	board[20] = -14;
	board[24] = -8 ;
	board[25] = 10;
	board[32] = -2;
	board[34] = -22;

	//standing at 1 and got 1 on die and on 2 I have ladder then edge  = 1 + 1 --> edge = edege + board[edge]

	Graph<int> g;

	for (int i = 0; i <= 36; i++)
	{
		for (int dice = 1; dice <= 6; dice++)
		{
			int edge = i + dice;
			edge += board[edge];
			if (edge <= 36)
				g.addedge(i, edge); //This are unweighted , directed edges
		}
	}

	g.addedge(36, 36);

	cout << endl << g.bfs(0, 36) << endl;

	return 0;
}