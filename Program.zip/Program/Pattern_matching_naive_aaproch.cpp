#include<iostream>
#include<bits/stdc++.h>

using namespace std;

//Pattern Matching Naive solution
int main()
{

	string str;
	string pat;

	cin >> str >> pat;

	int len1 = str.length();
	int len2 = pat.size();

	cout << str << " " << pat << endl;
	for (int i = 0; i <= len1 - len2; i++) {
		int j;
		for (j = 0; j < len2; j++) {
			if (str[i + j] != pat[j])
				break;
		}
		if (j == len2)
			cout << "Patten match from idx " << i << "to " << i + j - 1 << endl;
	}


	return 0;

}