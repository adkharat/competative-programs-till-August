#include<bits/stdc++.h>

using namespace std;

/*int firstoccurance(int *arr, int n, int key)
{
	if (n == 0)
		return -1;

	if (arr[0] == key)
		return 0;

	int pos = firstoccurance(arr + 1, n - 1, key);

	if (pos == -1)
		return -1;

	return pos + 1;
}*/

int firstoccurance_2(int *arr, int n, int index, int key)
{
	if (index == n)
		return -1;

	if (arr[index] == key)
		return index;

	return firstoccurance_2(arr, n ,  index + 1, key);
}

int main()
{
	int n; cin >> n;
	int arr[n];

	for (int i = 0; i < n; i++)
		cin >> arr[i];
	int key; cin >> key;

	cout << "First Occurance " << firstoccurance_2(arr, n, 0, key) << endl;
//	cout << "First Occurance " << firstoccurance(arr, n, key) << endl;

	return 0;
}