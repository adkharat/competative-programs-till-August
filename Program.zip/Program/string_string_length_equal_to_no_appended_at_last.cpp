#include <bits/stdc++.h>
using namespace std;

bool isequal(string s) {

	int n = s.length();
	int num = 0;
	int x = 1;
	int i = n - 1;

	for (i = n - 1; i >= 0; i--) {
		if (s[i] >= '0' and s[i] <= '9') {
			num = (s[i] - '0') * x + num;
			x = x * 10;
			if (num >= n)
				return false;
		}
		else
			break; //encounter charater and not digit
	}
	// Check if number is equal to string length except
	// that number's digits
	return num == i + 1;

}

int main(int argc, char const *argv[])
{

	string s; cin >> s;

	if (isequal(s))
	{
		/* code */
		cout << "YES" << endl;
	}
	else
		cout << "NO" << endl;

	return 0;
}