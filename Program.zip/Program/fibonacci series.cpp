#include <iostream>
#include <bits/stdc++.h>
using namespace std;

int f1(int n)
{
	if (n == 0 || n == 1)
		return n;
	else
		return f1(n - 1) + f1(n - 2);

}


int   main()
{

	int t; cin >> t;
	while (t--) {
		int n; cin >> n;
		cout << f1(n);

	}
}