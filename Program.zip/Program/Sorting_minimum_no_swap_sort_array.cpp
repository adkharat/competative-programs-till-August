#include<bits/stdc++.h>

using namespace std;
/*
//Minimum number of Swap to Sort Array of "n" element

void selectionSort(int arr[], int n)
{
	int i, j, min_idx, count=0;

	// One by one move boundary of unsorted subarray
	for (i = 0; i < n-1; i++)
	{
		// Find the minimum element in unsorted array
		min_idx = i;
		for (j = i+1; j < n; j++)
		if (arr[j] < arr[min_idx])
			min_idx = j;

		// Swap the found minimum element with the first element
		if(min_idx!=i)	{
      swap(&arr[min_idx], &arr[i]);
          count++;
        }
	}
  cout<<"minimum no of swap required are "<<count<<endl;
}
//O(n^2) //But not always gives minimum swap
*/

// Driver program to test above functions
int main()
{
	int arr[] = {64, 25, 12, 22, 11};
	//11 25 12 22 64
	//11 12 25 22 64
	//11 12 22 25 64
	int n = sizeof(arr) / sizeof(arr[0]);
	selectionSort(arr, n);
	cout << "Sorted array: \n";
	printArray(arr, n);
	return 0;
}
