#include<bits/stdc++.h>

using namespace std;

int findSquareRoot(int n) {

	int start = 0, end = n;
	int res;

	//Base case
	if (n == 0 || n == 1)
		return n;

	while (start < end) {
		int mid = (start + end) / 2;
		if (mid * mid == n)
			return mid;


		if (mid * mid < n) {
			start  = mid + 1;
			res = mid;//floor value
		}
		else
			end = mid - 1;
	}

	return res;

}

int main() {

	int n; cin >> n;

	cout << findSquareRoot(n);


	return 0;
}