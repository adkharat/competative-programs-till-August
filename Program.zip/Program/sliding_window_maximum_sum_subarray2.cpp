#include<iostream>
#include<bits/stdc++.h>

using namespace std;


int main()
{
	int arr[] = {1, 4, 2, 10, 2, 3, 1, 0, 20 };
	int n = sizeof(arr) / sizeof(arr[0]);

	int k; cin >> k;

	int max_sum = 0;
	int win_sum = INT_MIN;

	for (int i = 0; i < k; i++)
	{
		max_sum += arr[i];
	}

	win_sum = max_sum;
	for (int i = k; i < n; i++)
	{
		win_sum = win_sum + arr[i] - arr[i - k];
		max_sum = max(max_sum, win_sum);
	}

	cout << "Maximum sum subarray of size K is " << max_sum << endl;

	return 0;

}