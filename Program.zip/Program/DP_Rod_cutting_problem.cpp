#include<iostream>
#include<bits/stdc++.h>

using namespace std;

//Given a rod of length n inches and an array of prices that contains prices of all pieces of size smaller than n.
//Determine the maximum value obtainable by cutting up the rod and selling the pieces.

struct rod {
	int len;
	int price;
};

int cutROD(rod item[], int n) {

	int DP[n + 1]; DP[0] = 0;

	for (int i = 1; i <= n; i++) {
		int max_val = INT_MIN;
		for (int j = 0; j < i; j++) {
			max_val = max(max_val, item[j].price + DP[i - j - 1]);
			DP[i] = max_val;
		}
	}

	return DP[n];
}



int main() {

	int n; cin >> n;
	rod r[n];

	for (int i = 0; i < n; i++) {
		int x;  x = i + 1;
		int y; cin >> y;
		r[i].len = x;
		r[i].price = y;
	}


	cout << "maximum value obtained by cutting rod " << cutROD(r, n);

	return 0;
}

//8
//1 5 8 9 10 17 17 20