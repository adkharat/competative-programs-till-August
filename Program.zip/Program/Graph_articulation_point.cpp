#include <bits/stdc++.h>
using namespace std;


class Graph
{
	int V;
	list<int> *l;
	int *disc, *low;
	vector<int> art_pt;
	vector<pair<int, int>> bridge;

public:
	Graph(int v)
	{
		this->V = v;
		l = new list<int>[V];
		disc = new int[V] {0};
		low = new int[V] {0};

	}

	void addedge(int x, int y) {
		l[x].push_back(y);
		l[y].push_back(x);
	}

	void printAdjList() {
		for (int i = 1; i < V; i++) {
			cout << "Vertex " << i << "-->";
			for (auto x : l[i])
				cout << x << " ";
			cout << endl;
		}
	}

	void dfs(int src, int parent) {
		//cout << "ajay";
		static int time = 0;
		disc[src] = low[src] = ++time;
		//cout << "Initially Disc and low of SRC " << disc[src] << " " << low[src] << " ";
		int no_of_child = 0;
		for (auto child : l[src]) {
			//If chile is not discovered
			if (!disc[child]) //If not visited can be obtained using disc[] array itself//Disc time of every node by default is zero
			{
				no_of_child++;
				dfs(child, src);


				low[src] = min(low[src], low[child]); //mini of current node and all the child node
				cout << "Lower of" << src << "--> " << low[src] << " ";
				//Artic Point?
				if (parent != 0 and low[child] >= disc[src]) //we will have separate case for root
				{art_pt.push_back(src); cout << "Pushed " << src << " "; }
				//cout << "Kharat" << " ";
				//Bridge
				if (low[child] > disc[src])
					bridge.push_back({src, child});
			}
			else if (child != parent) //child is visited
			{	//backage
				//cycle found{
				//cout << "Done" << " ";
				low[src] = min(low[src], disc[child]);//mini of curr and where backage is pointing //bachage is pointing to child node

			}
		}

		//Separate case for root node. For root to be a arti point it must have more than 2 node atleast.
		if (parent == 0 and no_of_child >= 2)
			art_pt.push_back(src);
	}

	void articulation_points() {
		for (auto x : art_pt)
			cout << x << " ";
		// cout << "art point size " << art_pt.size() << endl;
		cout << endl;
		for (auto x : bridge)
			cout << x.first << " " << x.second << " ";
	}
};


int main() {

	int m, n; cin >> n >> m;
	Graph g(n + 1);
	for (int i = 0; i < m; i++) {
		int x, y; cin >> x >> y;
		//x--; y--;
		g.addedge(x, y);
	}
	//src and parent
	g.dfs(1, 0);
	g.printAdjList();
	g.articulation_points();


	return 0;
}