#include<iostream>
#include<bits/stdc++.h>

using namespace std;

void permute(string s, int l, int r) {

	//Base case
	if (l == r)
		cout << s << endl;
	else {
		for (int i = l; i <= r; i++) { //For loop help in swaping
			swap(s[l], s[i]); //Fix Lth position at ith level e.g.ABC
			permute(s, l + 1, r); //Move to next level for fixing
			swap(s[l], s[i]); //Restore Back //Backtracking
		}
	}

}

int main() {

	string s;
	cin >> s;
	int l = 0, r = (s.size()) - 1;
	permute(s, l, r);
	return 0;
}