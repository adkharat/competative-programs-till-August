#include<iostream>
#include<bits/stdc++.h>

using namespace std;
char a[100];

void printBitString(int low, int high) {

	if (low == high)
		cout << a << endl;
	else {
		a[low] = '0';
		printBitString(low + 1, high);
		a[low] = '1';	//backtracking
		printBitString(low + 1, high); //backtracking
	}

}

int main() {

	int n; cin >> n; //Input no of Bits
	int low = 0, high = n;
	printBitString(low, high);

	return 0;
}