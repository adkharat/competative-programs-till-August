#include <bits/stdc++.h>
using namespace std;
void stock_span(int price[], int span[], int n) {

	stack<int> s;
	span[0] = 1;
	s.push(0);
	for (int i = 1; i < n; i++) {

		while (!s.empty() and price[s.top()] <= price[i]) //If we found any greater element than top of stack then remove top and push this new element
			s.pop();

		span[i] = s.empty() ? i + 1 : i - s.top();

		s.push(i); //insert larger element in incresing sequence
	}

}

int main()
{
	// added the two lines below
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);

	int t; cin >> t;
	while (t--) {
		int n; cin >> n;
		int arr[n];
		int span[n];
		for (int i = 0; i < n; i++)
			cin >> arr[i];
		stock_span(arr, span, n);

		for (int i = 0; i < n; i++)
			cout << span[i] << " ";
	}

	return 0;
}
//10 4 5 90 120 80