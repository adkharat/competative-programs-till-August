11 - Jul - 2020
void addedge(int x, int y) {
	l[x].push_back(y);
}

void dfs_utility(int src, bool *visited, list<int> &s) {

	visited[src] = true;

	for (auto nbr : l[src])
		if (!visited[nbr])
			dfs_utility(nbr, visited, s);

	s.push_front(src); //Before returninng back push the last node in front of link list

}

void topologocal_dfs_sort()
{
	bool *visited = new bool[V];
	list<int> s;

	for (int i = 0; i < V; i++)
		visited[i] = false;

	dfs_utility(0, visited, s);

	cout << "topologocal_dfs_sort ";
	for (auto x : s)
		cout << x + 1 << " ";

}


};

int main() {
	int n, e; cin >> n >> e;
	Graph g(n);

	for (int i = 0; i < e; i++) {
		int x, y; cin >> x >> y;
		g.addedge(x - 1, y - 1);
	}

	g.topologocal_dfs_sort();
	return 0;
}