#include<cstdio>
#include <bits/stdc++.h>

using namespace std;


class Solution {
public:

	string simplifyPath(string path) {

		string temp = "";
		string ans;

		stack<string> s;
		int n = path.size();

		for (int i = 0; i < n; i++) {
			temp = "";

			if (path[i] == '/')
				continue;
			else {
				while (path[i] != '/' and i < n) {
					temp += path[i]; //	cout << temp << endl;
					i++;
				}

				if (temp == ".")
					continue;
				else if (temp != "..")
					s.push(temp);
				else if (temp == ".." and !s.empty())
					s.pop();
			}


		}

		if (s.empty())
			return "/";
		while (!s.empty())
		{
			ans = "/" + s.top() + ans;
			s.pop();
		}


		return ans;

	}
};



int main() {


	string s = "/..a/b/c//.///../";

	Solution obj;

	cout << obj.simplifyPath(s) << endl;



	return 0;
}

/*
string st;
		stack<string>s;
		string temp = "";
		int n = path.size();
		for (int i = 0; i < n; i++) {
			temp = "";

			if (path[i] == '/') {
				continue;
			} else {
				while (path[i] != '/' and i < n) {
					temp += path[i];
					i++;
				}

				if (temp == ".")
				{
					continue;
				} else if (temp != "..") {
					s.push(temp);
				} else if (temp == ".." and !s.empty()) {
					s.pop();
				}
			}


		}

		if (s.empty())return "/";
		while (!s.empty()) {
			st = "/" + s.top() + st;
			s.pop();
		}

		return st;

		*/