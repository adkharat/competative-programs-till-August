#include<iostream>
#include<bits/stdc++.h>

using namespace std;


class Graph
{

	map<int , list<pair<int, int>> > m;
	//map<int , list<pair<int, int>>, greater<int> > m;

public:

	void addedge(int x, int y, int wt)
	{
		m[x].push_back(make_pair(y, wt));
		m[y].push_back(make_pair(x, wt));
	}

	void printadjlist()
	{
		for (auto child : m) {
			int src = child.first;
			list<pair<int, int>> dest_pair = child.second;
			cout << src << "--> ";
			for (auto l : dest_pair)
			{
				int dest_node = l.first;
				int cost = l.second;
				cout << "(" << dest_node << "," << cost << ")" ;
			}

			cout << endl;
		}
	}




};


int main()
{
	Graph g;

	g.addedge(1, 2, 4);
	g.addedge(2, 4, 5);
	g.addedge(3, 4, 6);
	g.addedge(1, 3, 7);
	g.addedge(1, 4, 8);
	g.addedge(2, 3, 9);

	g.printadjlist();


	return 0;
}