#include <bits/stdc++.h>
using namespace std;

class Graph {
	int V;
	list<int> *l;

public:

	Graph(int v) {
		this->V = v;
		l = new list<int>[V];
	}

	void addedge(int x, int y) {
		l[x].push_back(y);
	}


	void topological_sort_bfs() {
		bool *visited = new bool[V];
		int *indegree = new int[V];

		//We need indegree array to begin in bfs
		for (int i = 0; i < V; i++) {
			visited[i] = false;
			indegree[i] = 0;
		}

		//Find indegree of all vertices
		for (int i = 0; i < V; i++) {
			for (auto nbr : l[i]) {
				indegree[nbr]++;
			}
		}

		queue<int> q;

		//Find node whose indegree is 0 to push all them in queue
		for (int i = 0; i < V; i++)
			if (indegree[i] == 0)
				q.push(i);

		//one by one process queue nodes
		while (!q.empty()) {

			int a = q.front();
			cout << a << " ";
			q.pop();

			for (int nbr : l[a]) {
				indegree[nbr]--;
				if (indegree[nbr] == 0)
					q.push(nbr);
			}
		}

	}


};

int main() {

	int n, e; cin >> n >> e;
	Graph g(n);

	for (int i = 0; i < e; i++) {
		int x, y; cin >> x >> y;
		g.addedge(x, y);
	}
	g.topological_sort_bfs();
	return 0;
}

/*  Graph g(6);
   g.addEdge(5, 2);
   g.addEdge(5, 0);
   g.addEdge(4, 0);
   g.addEdge(4, 1);
   g.addEdge(2, 3);
   g.addEdge(3, 1);
   */