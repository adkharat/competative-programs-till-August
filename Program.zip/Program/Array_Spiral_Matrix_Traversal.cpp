#include <bits/stdc++.h>
using namespace std;
#define R 4
#define C 4
int main() {
	int arr[R][C] = {{5, 6, 1, 2},
		{10, 25, 56, 23},
		{20, 18, 10, 78},
		{4, 9, 4, 1}
	};
	int n = sizeof(arr) / sizeof(arr[0]);
	int top = 0, bottom = n - 1, left = 0, right = n - 1; //2 pointer for Rows and 2 pointer for columns
	int dir = 0;
	while (top <= bottom and left <= right) {
		if (dir == 0) {//left to right
			for (int i = left; i <= right; i++)
				cout << arr[top][i] << " ";
			top++;
		}
		else if (dir == 1) { //top to bottom
			for (int i = top; i <= bottom; i++)
				cout << arr[i][right] << " ";
			right--;
		}
		else if (dir == 2) //right to left
		{
			for (int i = right; i >= left; i--)
				cout << arr[bottom][i] << " ";
			bottom--;
		}
		else if (dir == 3)//bottom to top
		{
			for (int i = bottom; i >= top; i--)
				cout << arr[i][left] << " ";
			left++;
		}
		dir = (dir + 1) % 4;
		//cout << "Direction is " << dir << endl;
	}

	return 0;
}