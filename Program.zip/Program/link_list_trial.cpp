#include<iostream>
#include<bits/stdc++.h>

using namespace std;

class node
{
public:
	int data;
	node *link;
};

void print_list_1(node **head) {
	node **temp = head;
	while (*temp != NULL) {
		(*temp)->data += 2;
		cout << (*temp)->data << " ";
		*temp = (*temp)->link;
	}

}

void print_list_2(node *head) {
	node *temp = head;
	while (temp != NULL) {
		temp->data += 2;
		cout << temp->data << " ";
		temp = temp->link;
	}

}

int main()
{

	node *first = new node(); node *second = new node(); node *third = new node(); node *four = new node();

	first->data = 5;
	second->data = 15;
	third->data = 25;
	four->data = 35;

	first->link = second;
	second->link = third;
	third->link = four;
	four->link = NULL;


	node *head = first;
	node *temp = head;
	while (temp ->link != NULL)
	{
		temp->data += 20;
		cout << temp->data << " ";
		temp = temp->link;
	}

	cout << endl;

	print_list_1(&head);
	print_list_2(head);
	return 0;
}