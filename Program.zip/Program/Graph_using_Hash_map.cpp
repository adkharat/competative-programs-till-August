#include<iostream>
#include<bits/stdc++.h>
using namespace std;
class Graph {

	unordered_map<string, list<pair<string, int> > > l;

public:

	void addedge(string x, string y, bool bdir, int wt)
	{
		l[x].push_back(make_pair(y, wt));
		if (bdir)
			l[y].push_back(make_pair(x, wt));
	}

	void printAdjlist() {

		for (auto city : l) {
			string x1 = city.first;
			list<pair<string, int>> nbrs = city.second;
			cout << x1 << "--> ";
			for (auto nbr : nbrs)
				cout << "(" << nbr.first << "," << nbr.second << ")";

			cout << endl;
		}

	}

};

//Weighted Graph + vertex are charater
int main()
{

	Graph g;
	g.addedge("A", "B", true, 20);
	g.addedge("D", "B", true, 40);
	g.addedge("A", "C", true, 10);
	g.addedge("C", "D", true, 40);
	g.addedge("A", "D", false, 50);

	g.printAdjlist();

	return 0;
}