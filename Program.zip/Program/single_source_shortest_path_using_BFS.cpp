#include<iostream>
#include<bits/stdc++.h>
using namespace std;

template<typename T>
class graph
{

	map<T, list<T> > m;

public:


	void addedge(T src, T dest)
	{

		m[src].push_back(dest);
		m[dest].push_back(src);
	}


	void printadjlist()
	{

		for (auto city : m)
		{
			T src = city.first;
			list<T> nbrs = city.second;

			cout << src << "-->";

			for (auto nbr : nbrs)
			{
				cout << nbr << ",";
			}

			cout << endl;
		}
	}


	void dfshelper(queue<T> &q, map<T, int> &distance)
	{

		while (!q.empty())
		{
			int expl = q.front();
			//cout<<q.front()<<" ";
			q.pop();

			cout << expl << " --> ";
			for (auto nbr : m[expl])
			{
				if (distance[nbr] == INT_MAX) { //if not visited ever before (if already visited then distnace won't be zero)
					q.push(nbr);
					distance[nbr] = distance[expl] + 1; //distance of neighbour is shortest distance to parent + 1

				}

			}

		}

	}



	void bfs(T src)
	{
		queue<int> q;
		map<T, int> distance;

		for (auto node_pair : m)
		{
			T node = node_pair.first;
			distance[node] = INT_MAX;
		}

		q.push(src);
		distance[src] = 0; //Distance of source to source node is zero

		dfshelper(q, distance);


		cout << endl;
		for (auto node_pair : m) {
			T node = node_pair.first;
			int dist = distance[node];
			cout << node << " " << dist << endl;
		}


	}



};


int main()
{

	graph<int> g;

	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(0, 3);
	g.addedge(3, 4);
	g.addedge(5, 4);


	g.printadjlist();


	g.bfs(0);

	return 0;
}