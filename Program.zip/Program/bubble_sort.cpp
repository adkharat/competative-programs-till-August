#include<iostream>

#include<bits/stdc++.h>

using  namespace std;

void bubble_sort(int *arr, int n)
{	// Last i elements are already in place
	for (int i = 0; i < n - 1; i++) {

		for (int j = 0; j < n - 1 - i; j++) {
			if (arr[j] > arr[j + 1])
			{
				int temp = arr[j]; arr[j] = arr[j + 1]; arr[j + 1] = temp;
			}
		}
	}
}

int main() {

	int arr[20] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
	cout << endl << "before sort" << endl;
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << " ";
	}
	cout << endl << "After Sort" << endl;
	bubble_sort(arr, 10);

	for (int i = 0; i < 10; i++) {
		cout << arr[i] << " ";
	}

	return 0;
}