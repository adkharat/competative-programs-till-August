#include<iostream>
#include<bits/stdc++.h>
#include<climits>
using namespace std;

//Top Down DP = Recursion + Memorization
int fib_top_down(int *dp_arr, int n)
{
	if (n == 0 || n == 1)
	{
		dp_arr[n] = n;
		return n;
	}

	dp_arr[n] = fib_top_down(dp_arr, n - 1) + fib_top_down(dp_arr, n - 2);

	return dp_arr[n];

}
//Bottom Up approch = Itteration + Memorization
int fib_bottom_up(int *dp_arr, int n)
{

	dp_arr[0] = 0;
	dp_arr[1] = 1;

	for (int i = 2; i <= n; i++)
	{
		dp_arr[i] = dp_arr[i - 1] + dp_arr[i - 2];
	}

	return dp_arr[n];


}


int main()
{

	int t; cin >> t;

	while (t--)
	{

		int n; cin >> n;
		int dp_arr[n + 1];
		//cout << fib_top_down(dp_arr, n) << endl;
		cout << fib_bottom_up(dp_arr, n) << endl;

		for (int i = 0; i <= n ; i++)
			cout << dp_arr[i] << " ";

	}

	return 0;
}