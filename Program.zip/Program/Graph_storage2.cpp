#include<iostream>
#include<bits/stdc++.h>

using namespace std;

bool compare(pair<int, int> p1, pair<int, int> p2)
{
	return p1.second < p2.second;

}


int main()
{
	int n, m; cin >> n >> m;
	vector<pair<int, int> > v[n];

	for (int i = 0; i < m; i++)
	{	int x, y, wt; cin >> x >> y >> wt;
		x--, y--;
		v[x].push_back(make_pair(y, wt));
		v[y].push_back(make_pair(x, wt));
	}


	for (int i = 0; i < n; i++)
		sort(v[i].begin(), v[i].end(), compare);

	for (int i = 0; i < n; i++) {
		cout << i + 1 << "--> ";
		for (auto x : v[i])
			cout << "(" << x.first + 1 << ", " << x.second << ")" << " ";
		cout << endl;
	}


	return 0;
}