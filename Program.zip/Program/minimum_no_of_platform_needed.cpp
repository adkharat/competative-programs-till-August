#include<iostream>
#include<bits/stdc++.h>

using namespace std;


int main()
{

	//int n; cin >> n;

	vector<int> arr = {900, 940, 950, 1100, 1500, 1800 };
	vector<int> dept = {910, 1200, 1120, 1130, 1900, 2000 };
	int n = arr.size();
	sort(arr.begin(), arr.end());
	sort(dept.begin(), dept.end());

	int i = 1, j = 0, plat = 1, count = 1;

	while (i < n && j < n)
	{
		if (arr[i] < dept[j])
		{
			count++;
			i++;
		}
		else if (arr[i] > dept[j]) {
			count--;
			j++;
		}

		if (count > plat) plat = count;
	}
	cout << plat << endl;

	return 0;
}