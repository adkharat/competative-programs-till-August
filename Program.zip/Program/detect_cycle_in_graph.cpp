#include<iostream>
#include<bits/stdc++.h>
using namespace std;


class graph
{
	int V;
	list<int> *l;

public:

	graph(int v) {
		this->V = v;
		l = new list<int> [V];
	}

	void addedge(int src, int dest)
	{

		l[src].push_back(dest);
		l[dest].push_back(src);

	}

	void printadjlist()
	{

		for (int i = 0; i < V; i++) {
			cout << i << " -->";
			for (auto nbr : l[i])
			{
				cout << nbr << " ,";
			}
			cout << endl;
		}

	}

	bool dfshelper(int src, bool *visited, int parent)
	{
		visited[src]  = true;

		for (auto nbrs : l[src])
		{
			if (!visited[nbrs]) {
				bool cycle_mele  = dfshelper(nbrs, visited, src);
				if (cycle_mele)
					return true;
			}
			else if (nbrs != parent) //neighbour is visited and is not a parent
				return true;	//Cycle is detected and return true to recursive calling function
		}


		return false;

	}


	void dfs(int src)
	{
		bool *visited = new bool [V];

		for (int i = 0; i < V; i++)
			visited[i] = false;

		bool result = dfshelper(src, visited, -1);

		if (result)
			cout << "Cycle is detected " << endl;
		else
			cout << "Cycle is not detected " << endl;
	}


};



int main()
{

	graph g(5);

	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(0, 3);
	g.addedge(3, 4);


	g.printadjlist();


	g.dfs(0);



	return 0;
}
