#include<iostream>
#include<climits>
#include<cmath>
#include<cstring>
#include<bits/stdc++.h>
#include<cstdlib>

using namespace std;


// Complete the sockMerchant function below.
int sockMerchant(int n, vector<int> ar) {

	map<int, int> mp;

	for (int i = 0; i < n; i++) {
		cout << ar[i] << " ";
		mp[ar[i]] = mp[ar[i]] + 1;
	}

	for (auto x : mp) {
		//cout << x.first << " " << (x.second / 2) << endl;
		sum += (x.second / 2);
	}
	for (int i = 0; i < n; i++)
		sum += mp[i] / 2;

	return sum;
}

//Using C
int sockMerchant2(int n, vector<int> ar)
{

	vector<int> v = {10, 20, 20, 10, 10, 30, 50, 10, 20};
	bool flag[100] = {0};
	int mp[100] = {0};

	int sum = 0;
	for (int i = 0; i < 9; i++) {
		mp[v[i]] += 1;
	}

	for (int i = 0; i < 9; i++) {
		if (flag[v[i]] == 0) {
			sum += (mp[v[i]] / 2);
			flag[v[i]] = 1;
		}
		cout << mp[v[i]] << endl;
	}

	return sum;
}


int main()
{

	vector<int> v = {10, 20, 20, 10, 10, 30, 50, 10, 20};
	int res = sockMerchant(9, v);
	//sockMerchant(9, v);

	cout << res << endl;

	return 0;
}