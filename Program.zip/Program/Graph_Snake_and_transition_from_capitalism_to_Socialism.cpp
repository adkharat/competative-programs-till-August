#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;
#define N 507
#define mod 1000000007

ll dx[8] = {1, 1, 1, 0, 0, -1, -1, -1};
ll dy[8] = {1, 0, -1, 1, -1, 1, 0, -1};
ll vis[N][N] = {0}, dist[N][N] = {0} , g[N][N];
queue<pair<ll, ll>> q;

bool ok(ll x, ll y, ll n, ll m) {
	if (x >= 1 and x <= n and y <= m  and y >= 1) return true;
	return false;
}

void bfs(ll n, ll m) {


	while (!q.empty()) {
		ll x = q.front().first;
		ll y = q.front().second;
		q.pop();

		vis[x][y] = 1;

		for (ll i = 0; i < 8; ++i) {
			if (ok(x + dx[i], y + dy[i], n, m) and !vis[x + dx[i]][y + dy[i]]) {
				dist[x + dx[i]][y + dy[i]] = 1 + dist[x][y];
				vis[x + dx[i]][y + dy[i]] = 1;
				q.push({x + dx[i], y + dy[i]});
			}
		}
	}
}

void clear() {

	for (ll i = 0; i < N; ++i) {
		for (ll j = 0; j < N; ++j) {dist[i][j] = 0; vis[i][j] = 0; g[i][j] = 0;}
	}

}


int main()
{
	ios_base::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);

	ll t;
	cin >> t;

	while (t--) {
		ll n, m;
		cin >> n >> m;

		ll maxa = 0;
		for (ll i = 1; i <= n; ++i) {
			for (ll j = 1; j <= m; ++j) {cin >> g[i][j]; maxa = max(maxa, g[i][j]);}
		}

		for (ll i = 1; i <= n; ++i) {
			for (ll j = 1; j <= m; ++j)
				if (g[i][j] == maxa) {q.push({i, j}); vis[i][j] = 1;}
		}

		bfs(n, m);

		maxa = 0;
		for (ll i = 1; i <= n; ++i)
			for (ll j = 1; j <= m; ++j) maxa = max(maxa, dist[i][j]);

		// for(ll i=1;i<=n;++i){
		// 	for(ll j=1;j<=m;++j) cout<<dist[i][j]<<" ";
		// 		cout<<"\n";
		// }

		cout << maxa << "\n";

		clear();

	}

	return 0;

}