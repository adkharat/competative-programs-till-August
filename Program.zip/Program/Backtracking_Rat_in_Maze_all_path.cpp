#include<iostream>
#include<bits/stdc++.h>

using namespace std;
void printSolution(int **solution, int n) {
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++) {
			cout << solution[i][j] << " ";
		}
	cout << endl;
}

void Helper(int in[][20], int n, int **solution, int x, int y) {

	if (x == n - 1 and y == n - 1)
	{
		solution[x][y] = 1;
		printSolution(solution, n);
		return;
	}

	if (x < 0 || x >= n || y < 0 || y >= n || in[x][y] == 0 || solution[x][y] == 1) //unsafe
		return;
	//safe
	solution[x][y] = 1;
	Helper(in, n, solution, x - 1, y); //Top
	Helper(in, n, solution, x + 1, y); //Bottom
	Helper(in, n, solution, x, y - 1); //Left
	Helper(in, n, solution, x , y + 1); //Right
	solution[x][y] = 0;
}

void ratMaze(int in[][20], int n) {
	int** solution = new int*[n];
	for (int i = 0; i < n; i++)
		solution[i] = new int[n];

	Helper(in, n, solution, 0, 0);
}

int main()
{
	int maze[][20] = {{ 1, 0, 0, 0 , 0},

		{ 1, 1, 0, 1, 0 },

		{ 0, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 0 },
		{ 0, 1, 1, 1, 1 }
	};
	int n = 5;
	ratMaze(maze, n);
	return 0;
}