#include <bits/stdc++.h>
using namespace std;

int main() {
	int arr[] = {10, 20, 30, 5, 10, 20, 50};
	int n = sizeof(arr) / sizeof(arr[0]);
	int span[n];
	span[0] = 1;
	for (int i = 1; i < n; i++) {
		span[i] = 1;

		if (arr[i - 1] < arr[i])
			span[i] = span[i - 1] + 1;


	}

	for (int i = 0; i < n; i++)
		cout << span[i] << " ";

	return 0;
}