#include<iostream>
#include<bits/stdc++.h>

using namespace std;

/*Given a value N, if we want to make change for N cents, and
we have infinite supply of each of S = { S1, S2, .. , Sm} valued coins,
how many ways can we make the change? The order of coins doesn’t matter.
*/


int count(int arr[], int n, int m) {

	cout << "SUM valued " << m << endl;
	//Similar to LIS
	int DP[m + 1];
	for (int i = 0; i <= m; i++)
		DP[i] = m + 1;

	//memset(DP, m + 1, sizeof(DP));

	DP[0] = 0;


	for (int i = 0; i <= m; i++)
		cout << DP[i] << " ";

	cout << endl;

	for (int j = 1; j <= m; j++) { //m SUM
		for (int i = 0; i < n; i++) { //n coins
			if (arr[i] <= j and DP[j - arr[i]] + 1 < DP[j])
				DP[j] = DP[j - arr[i]] + 1;
		}
	}



	for (int i = 0; i <= m; i++)
		cout << DP[i] << " ";

	cout << endl;
	return DP[m];
}



int main() {
	int coins[] = {1, 2, 5};
	int n = sizeof(coins) / sizeof(coins[0]);
	int m = 11;
	cout << "Mini coins needed " << count(coins, n, m);

	return 0;
}