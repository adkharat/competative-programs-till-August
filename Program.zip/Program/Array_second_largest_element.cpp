#include<bits/stdc++.h>
using namespace std;

vector<int> second_largest(int arr[], int n) {

	int largest_1, largest_2, smallest_1, smallest_2;
	largest_1 = largest_2 = INT_MIN;
	smallest_1 = smallest_2 = INT_MAX;

	vector<int> res;
	//Get 1st largest element
	for (int i = 0; i < n; ++i)
	{
		/* code */
		largest_1 = max(largest_1, arr[i]);
		smallest_1 = min(smallest_1, arr[i]);
	}
	//get 2nd largest element
	for (int i = 0; i < n; ++i)
	{
		/* code */
		if (arr[i] != largest_1)
			largest_2 = max(largest_2, arr[i]);
		if (arr[i] != smallest_1)
			smallest_2 = min(smallest_2, arr[i]);
	}
	res.push_back(largest_1); res.push_back(largest_2); res.push_back(smallest_1); res.push_back(smallest_2);
	return res;
}

int main() {

	int arr[] = {3, 4, 1, 34, 56, 24, 67};
	int n = sizeof(arr) / sizeof(arr[0]);
	vector<int> res = second_largest(arr, n);
	for (auto x : res)
		cout << x << endl;

}