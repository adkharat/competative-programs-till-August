/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include<bits/stdc++.h>

using namespace std;

class mylist
{
    public:
    string first;
    int age;
};

bool mycomp(mylist l1,mylist l2)
{
    return l1.age > l2.age;
}

int main()
{
 
    vector<mylist> v{{"ajay",2},{"akshu",4},{"akhil",9}};
    
    for(auto x: v)
    cout<<"["<<x.first <<" "<<x.age<<"]"<<endl;
 
    sort(v.begin(), v.end(), mycomp);
     
    for(auto x: v)
    cout<<"["<<x.first <<" "<<x.age<<"]"<<endl;
    
   return 0; 
}