#include <bits/stdc++.h>
using namespace std;




//For non negative no ONLY
void subarray_sum_k_1(vector<int> v, int x) {
	int l = 0, r = 0;
	int curr_sum = 0;
	int n = v.size();

//right pointer to incr cureent sum when cur_sum< given_sum
//Left pointer increment when curr_sum exceed given sum

	for (int i = 0; i < n; i++) {
		//If subarray sum exeded
		while (curr_sum > x and l < r) {
			curr_sum -= v[l];
			l++;
		}
		if (curr_sum == x)//Found Subarray with given sum
		{
			cout << "Got Subarray " << endl;
			break;

		}
		if (r < n)
		{
			curr_sum += v[r];
			r++;
			cout << curr_sum << " " << r << endl;
		}

	}
}

//Positive and Negative no both
void subarray_sum_k_2(vector<int> v,  int sum) {
// /The idea is to store the sum of elements of every prefix of the array in a hashmap,
//i.e for every index store the sum of elements upto that index hashmap.
	int curr_sum = 0;
	map<int, int> mp;//Key = curr_sum and value= index
	int n = v.size();
	for (int i = 0; i < n; i++) {
		curr_sum = curr_sum + v[i]; //Prefix sum //cummulative sum

		if (curr_sum == sum)
		{
			cout << "Subarray with given SUM found at index " << 0 << " " << i << endl;
			break;
		}
		if (mp.find(curr_sum - sum) != mp.end()) { //if Curr_sum exceed then this will be helpful
			cout << "Sum found between index " << mp[curr_sum - sum] + 1 << " and " << i << endl;
			break;
		}

		mp[curr_sum] = i; //Add prefix sum at index 'i' in hashmap
	}
	return;
	// arr[] = {1, 4, 20, 3, 10, 5}, sum = 33
//    1->0
//    5->1
//    25->2
//    28->3
//    38

	//we already have unwanted sum of 5 tracked  as a prefix sum at index 1
}

int main() {

	vector<int> v = { 1, 4, 20, 3, 10, 5};
	int sum = 33;
//left to decrease sum
	//right to increase sum
	subarray_sum_k_2(v, sum);



	return 0;
}