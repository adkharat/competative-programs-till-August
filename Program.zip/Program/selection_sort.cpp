#include<iostream>

#include<bits/stdc++.h>

using  namespace std;

void swap(int *p1, int *p2) {

	int temp = *p1;
	*p1 = *p2;
	*p2 = temp;
}

void selection_sort(int *arr, int n) {
	// Last i elements are already in place
	for (int i = 0; i < n - 1; i++) {
		int min_idx = i;
		for (int j = i + 1; j < n; j++) //Find minimum index
		{
			if (arr[j] < arr[i]) min_idx = j;
		}

		swap(&arr[i], &arr[min_idx]);

	}

}


int main()
{

	int arr[20] = {10, 9, 8, 7, 6, 5, 4, 3, 2, 1};
	cout << endl << "before sort" << endl;
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << " ";
	}
	cout << endl << "After Sort" << endl;

	selection_sort(arr, );
	for (int i = 0; i < 10; i++) {
		cout << arr[i] << " ";
	}

	return 0;
}