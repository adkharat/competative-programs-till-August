#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main()
{
	int n; cin >> n;

	int *arr = new int [n];

	int longest_subarray = 0;


	for (int i = 0; i < n; i++)
	{
		cin >> arr[i];
	}
	cout << endl;

	int prefix_sum = 0;
	map<int, int> m;
	//Insert every occurance of 1st elemt in Dict and every 2nd/3 occu (subarray sum= 0) subtract from 1st occurance .
	//This give largest subarray with sum equals to 0
	//A prefix sum of 0 means subarray whose sum=0 is present
	for (int i = 0; i < n; i++)
	{
		prefix_sum += arr[i]; cout << prefix_sum << " ";
		if (prefix_sum == 0 ) longest_subarray = max(longest_subarray, i - 0 + 1);
		if (m.find(prefix_sum) != m.end()) //on every 2nd occurance
			longest_subarray = max(longest_subarray, i - m[prefix_sum] + 1); //Difference of index give length
		else //on every 1st occurance
			m[prefix_sum] = i;	//on 1st time occurance store index


		//on every other occur that subarray sum is 0

	}

	cout << "longest_subarray length " << longest_subarray << endl;


	return 0;
}