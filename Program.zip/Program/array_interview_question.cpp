#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int mini_perfect_square_lagranges(int n) { //O(n)

//CASE 1
	if (floor(sqrt(n)) == ceil(sqrt(n))) //no is a perfect square no.
		return 1;

//CASE 2 (4^a)*(8*B+7)
	while (n % 4 == 0)
		n = n / 4;
	if (n % 8 == 7)
		return 4;
//CASE 3
	for (int i = 1; i * i <= n; i++) {

		int base = sqrt(n - i * i);
		if (base * base == (n - i * i))
			return 2;
	}
//CASE 4
	return 3;

}


int mini_perfect_square_DP(int n) {//O(nsqrt(n))
	int dp[n + 1]; //since DP[0]=0, n+1 element
	dp[0] = 0;
	for (int i = 1; i <= n; i++) {
		dp[i] = i;
		for (int j = 1; j * j <= n; j++) {
			dp[i] = min(dp[i], 1 + dp[i - j * j]);
		}
	}

	return dp[n];
}

//Dutch national flag
void segregate_0_1_2(int arr[], int n) {

	int low, high, mid;
	low = mid = 0; high = n - 1; //index

	while (mid < high) {
		switch (arr[mid]) {
		case 0: swap(arr[low], arr[mid]);
			low++; mid++;
			break;

		case 1:	mid++;
			break;

		case 2: swap(arr[mid], arr[high]);
			high--;
			break;

		}
	}

}


void sort_negative_positive(int arr[], int n) {

	int low, high;
	low = 0; high = n - 1; //Index

	while (low < high) {
		if (arr[low] < 0 and low < high)//No is negative
			low++;
		if (arr[high] > 0 and low < high) //no is positive
			high--;
		//we have found a no from LHS greater than o and from RHS less than 0
		if (low < high)
			swap(arr[low], arr[high]);
		else
			break;
	}

}

void sort_0_and_1(int arr[], int n) {

	int low, high;
	low = 0; high = n - 1; //Index

	while (low < high) {
		if (arr[low] == 0 and low < high)//No is negative
			low++;
		if (arr[high] == 1 and low < high) //no is positive
			high--;
		//we have found a no from LHS greater than o and from RHS less than 0
		if (low < high)
			swap(arr[low], arr[high]);
		else
			break;
	}

}

bool check_pair(char c1, char  c2) {
	if (c1 == '(' and c2 == ')') return true;
	else if (c1 == '{' and c2 == '}') return true;
	else if (c1 == '[' and c2 == ']') return true;

	return false;
}

bool parenthesis_matching(char c[], int n) {
	stack<char> s;

	for (int i = 0; i < n; i++) {

		if (c[i] == '{' || c[i] == '[' || c[i] == '(') {
			s.push(c[i]);
			continue;
		}
		if (c[i] == '}' || c[i] == ']' || c[i] == ')')
		{
			if ( !check_pair(s.top(), c[i]) || s.empty()) {
				return false;
			}
			else
				s.pop();
		}
	}

	return s.empty() ? true : false;
}

//Moore's voting algo to find majority element
int majority_ele_sorted_array(vector<int> arr) {
	int n = arr.size();
	int majority_idx = 0, count = 1;

	for (int i = 1; i < n; i++) {
		if (arr[majority_idx] == arr[i])
			count++;
		else
			count--;
		//reinitilize majority element
		if (count == 0) {
			majority_idx = i;
			count = 1;
		}
	}


	int m_count = 0;
	//Recheck majority element
	for (int i = 0; i < n; i++) {
		if (arr[i] == arr[majority_idx])
			m_count++;
	}
	if (m_count > n / 2)
		return arr[majority_idx];

	return -1;
}

//Kadane's algo


//maximum diff bet 2 element a nd b such that b>a
vector<int> max_diff(vector<int> v) {
	int n = v.size();
	int mini_so_far = v[0];
	int max_diff = v[1] - v[0];
	int curr_diff = v[1] - v[0];
	int start = 0, end = 0, s = 0;
	for (int i = 1; i < n; i++) {
		if (v[i] < mini_so_far) {//found curr elem is minimum element
			mini_so_far = min(mini_so_far, v[i]);
			s = i;
		}
		else//curr ele is not minimum ele i.e its maxi ele
		{
			curr_diff = v[i] - mini_so_far;
			if (curr_diff > max_diff) {
				max_diff = max(max_diff, curr_diff);
				end = i;
				start = s;
			}
		}
	}

	vector<int> v1 = {start, end};
	cout << "Max diff " << max_diff << endl;
	return v1;

}

//array size(n+1) and element range is 1-->n and 1 additional duplicate item
int Duplicate_number(vector<int> arr) {
	//v4 = {1, 3, 4, 2, 2};
	int n = arr.size(); //5

	for (int i = 0; i < n; i++) {
		//Increase every array element by array size
		arr[arr[i]] = arr[arr[i % n]]  + n;
	}	//v4 = {1, 8, 14, 7, 7};


	int maxi = INT_MIN;
	int maxi_idx = 0;
	for (int i = 0; i < n; i++) {
		if (arr[i] > maxi) {
			maxi =  arr[i];
			maxi_idx = i;
		}
	}

	return maxi_idx;
}

void find_duplicate(vector<int> arr)
{

	//v4 = {4, 3, 1, 1, 2,2,3,4};
	int n = arr.size(); //5

	for (int i = 0; i < n; i++) {

		//check arr[arr[i]] sign
		if (arr[abs(arr[i])] >= 0)
			//Multiply every array element by -1
			arr[abs(arr[i])] = -1 * arr[abs(arr[i])];
		//v4 = {4, -3, -1, -1, 2,2,3,4};
		else//Index arr[i] is repeating
			cout << " " << abs(arr[i]);
	}

}


int main() {
///////////////////////////////////////////////////////////////
	cout << mini_perfect_square_lagranges(13) << endl;
	cout << mini_perfect_square_DP(13) << endl;
///////////////////////////////////////////////////////////////////
	int seg[] = {1, 0, 2, 1, 0, 2, 1, 2, 0};
	int n1 = sizeof(seg) / sizeof(seg[0]);

	segregate_0_1_2(seg, n1);
	for (int i = 0; i < n1; i++) {
		cout << seg[i] << " ";
	}
	cout << endl;
////////////////////////////////////////////////////////////////////
	int pos_neg[] = { -5, -4, 2, 5, -9, 0, 8};
	int n2 = sizeof(pos_neg) / sizeof(pos_neg[0]);

	sort_negative_positive(pos_neg, n2);
	for (int i = 0; i < n2; i++) {
		cout << pos_neg[i] << " ";
	}
	cout << endl;
/////////////////////////////////////////////////////////////////////
	int seg_0_1[] = {1, 0, 0, 1, 0, 1, 0};
	int n4 = sizeof(seg_0_1) / sizeof(seg_0_1[0]);

	sort_0_and_1(seg_0_1, n4);
	for (int i = 0; i < n4; i++) {
		cout << seg_0_1[i] << " ";
	}
	cout << endl;
///////////////////////////////////////////////////////////////////////
	char c[] = "{()()}";
	int n3 = sizeof(c) / sizeof(c[0]);
	bool check = parenthesis_matching(c, n3);
	for (int i = 0; i < n3; i++) {
		cout << c[i] << " ";
	}

	if (check) cout << "Balanced " << endl;
	else cout << "Not balanced " << endl;

/////////////////////////////////////////////////////////////////////////
	vector<int> v1 = {2, 2, 2, 8, 3, 3, 3};

	cout << "Majority element is " << majority_ele_sorted_array(v1) << endl;
/////////////////////////////////////////////////////////////////////////
	vector<int> v2 = {4, 3, 10, 2, 1, 6};

	cout << "maximum diff is ";
	vector<int> v3 = max_diff(v2);
	for (auto x : v3)
		cout << x << " ";
	cout << endl;
/////////////////////////////////////////////////////////////////////////
	vector<int> v4 = {1, 3, 4, 2, 2};

	//cout << "Duplicate_number is " << Duplicate_number(v4) << endl;

/////////////////////////////////////////////////////////////////////////
	cout << "Repeated elelemt are " << endl;
	vector<int> v5 = {4, 3, 1, 2, 2, 3};
	find_duplicate(v5);

/////////////////////////////////////////////////////////////////////////







/////////////////////////////////////////////////////////////////////////

	return 0;
}