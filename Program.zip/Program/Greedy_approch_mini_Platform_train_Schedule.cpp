#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int main()
{
	int n; cin >> n; //No of trains

	vector<int> arr;
	vector<int> dep;

	for (int i = 0; i < n; i++) {
		int x, y; cin >> x >> y;
		arr.push_back(x);
		dep.push_back(y);
	}

	sort(arr.begin(), arr.end());
	sort(dep.begin(), dep.end());

	int cur = 1, max_plat = 1; //Already one train considered
	int i = 1 , j = 0; //Start from second train bcz 1st train need atleast one platform
	//Merge two sorted array
	while (i < n and j < n) {
		cout << "ajay" << endl;
		if (arr[i] <= dep[j]) { //On arrival event increaase total no of platform
			cur++;
			i++;
		}
		else if (arr[i] < dep[j]) { //On dept event decrease total no of platfrom
			cur--;
			j++;
		}

		max_plat = max(max_plat, cur); //Update maximum result
	}

	cout << "Minimum no of platform " << max_plat << endl;

	return 0;
}
// 900 940 950 1100 1500 1800
// 910 1200 1120 1130 1900 2000
6
// 900 910
// 940 1200
// 950 1120
// 1100 1130
// 1500 1900
// 1800 200