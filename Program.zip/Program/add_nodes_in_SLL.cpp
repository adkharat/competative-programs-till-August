#include<iostream>
#include<bits/stdc++.h>

using namespace std;

class node
{
public:
	int data;
	node *link;
};


void push_node_front(node **head_ref, int data_item) {


	node *new_node = new node();

	new_node->data = data_item;
	new_node->link = (*head_ref);

	(*head_ref) = new_node;
}


void insert_after_node(node *prev_node, int data_item) {

	if (prev_node == NULL) cout << "prev_node cannot be NULL";

	node *new_node = new node();

	new_node->data = data_item;
	new_node->link = prev_node->link;
	prev_node->link = new_node;


}


void append_at_last(node **head_ref, int data_item) {


	node *new_node = new node();
	new_node->data = data_item;
	new_node->link = NULL;

	if ((*head_ref) == NULL) {
		(*head_ref) = new_node;
		return;
	}

	node *last = (*head_ref);

	while (last->link != NULL) {
		last = last->link;
	}

	last->link = new_node;

	return;

}


void print_list(node *head) {
	node *temp = head;
	while (temp != NULL) {
		cout << temp->data << " ";
		temp = temp->link;
	}
}




int main()
{

	node *head = NULL;

	append_at_last(&head, 6);
	push_node_front(&head, 7);
	push_node_front(&head, 1);
	append_at_last(&head, 4);
	//insert_after_node(head->link, 8);

	print_list(head);
	cout << endl << head->data << " " << head->link->data << endl;
	insert_after_node(head->link, 8);
	cout << endl << head->data << " " << head->link->data << endl;
	cout << endl;
	print_list(head);
	return 0;

}