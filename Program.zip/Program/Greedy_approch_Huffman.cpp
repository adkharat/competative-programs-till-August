#include <iostream>
#include <bits/stdc++.h>
#define ll long long int
using namespace std;

int main() {
	//code
	ll t; cin >> t;
	while (t--) {
		ll n; cin >> n;
		priority_queue<int, vector<int>, greater<int>> pq;
		for (ll i = 0; i < n; i++) {
			ll x; cin >> x;
			pq.push(x);
		}

		ll sum = 0;

		while (pq.size() > 1) {
			ll f = pq.top(); pq.pop();
			ll s = pq.top(); pq.pop();
			sum += f + s;

			pq.push(f + s);
		}
		cout << sum << endl;
	}


	return 0;
