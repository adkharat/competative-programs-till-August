#include<iostream>
#include<cstring>
using namespace std;
//char* strtok( char* str, const char* delim );
int main(){

char str[] = "parrot,owl,sparrow,pigeon,crow";
char c[]=",";

    char *tok1 = strtok(str,c);
    cout<<tok1<<endl;
    tok1 = strtok(str,c);
    cout<<tok1<<endl;
    tok1 = strtok(NULL,c);
    cout<<tok1<<endl;

while(tok1!=NULL)
{
    tok1 = strtok(NULL,str);
    cout<<tok1<<endl;

}

return 0;
}




/*
#include<iostream>
#include<bits/stdc++.h>

using namespace std;
//char* strtok( char* str, const char* delim );
int main(){

string s;
string token;

getline(cin,s);

istringstream str_stm(s);

while(getline(str_stm,token,','))
    cout<<token<<endl;

return 0;
}

*/
