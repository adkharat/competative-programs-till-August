#include<iostream>
#include<bits/stdc++.h>

using namespace std;

void longestSubsequence(int arr[], int n) {

	map<int, int> mp;

	int DP[n];
	memset(DP, 0, sizeof(DP));


	int max_length = INT_MIN; //hold length of LIS
	int index = -1; //hold index of last element LIS

	for (int i = 0; i < n; i++) {

		if (mp.find(arr[i] - 1) != mp.end()) //check if previous conseq ele for me is present in array, so in set or not
		{
			//get prev conseq ele index from HASH MAP
			int lastindex = mp[arr[i] - 1] - 1;
			DP[i] = DP[lastindex] + 1; //length of previous elel + 1
		}
		else
			DP[i] = 1; //length of every new occurance ele is set 1

		//Also do insert every element in hash map
		mp[arr[i]] = i + 1; //MAP element to its index

		if (max_length < DP[i]) {
			max_length = DP[i];
			index = i;
		}
	}

	for (int curr = arr[index] - max_length + 1 ; curr <= arr[index] ; curr++)
		cout << curr << " ";

	//cout << *max_element(DP, DP + n) << endl;

}

int main() {

	int arr[] = { 3, 10, 3, 11, 4, 5, 6, 7, 8, 12 };
	int n = sizeof(arr) / sizeof(arr[0]);
	longestSubsequence(arr, n);
	return 0;
}