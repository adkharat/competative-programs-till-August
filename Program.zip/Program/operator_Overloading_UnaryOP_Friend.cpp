#include<iostream>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>

using namespace std;
class decrem
{
	int a;

public:

	decrem(int a = 0) {
		this->a = a;
	}

	void display() {
		cout << "a = " << a << endl;
	}

	friend decrem operator - (decrem);
};

//when using freind function all obj need to pass explicitly
//no obj is passed implicitl
decrem operator - (decrem a2) {
	decrem d3;
	d3.a = --a2.a;

	return d3;
}

int main() {

	decrem d1(4); //parameterized const
	decrem d2; //default constructor

	d1.display();

	d2 = -d1;

	d2.display();

	return 0;
}