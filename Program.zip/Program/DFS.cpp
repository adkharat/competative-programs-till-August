#include<iostream>
#include<bits/stdc++.h>
using namespace std;


class graph
{
	int V;
	list<int> *l;

public:

	graph(int v) {
		this->V = v;
		l = new list<int> [V];
	}

	void addedge(int src, int dest)
	{

		l[src].push_back(dest);
		l[dest].push_back(src);

	}

	void printadjlist()
	{

		for (int i = 0; i < V; i++) {
			cout << i << " -->";
			for (auto nbr : l[i])
			{
				cout << nbr << " ,";
			}
			cout << endl;
		}

	}

	void dfshelper(int src, map<int, int> &visited)
	{
		cout << src << "-->";
		visited[src] = 1;

		for (auto nbr : l[src])
		{
			if (!visited[nbr])
				dfshelper(nbr, visited);
		}

	}


	void dfs(int src)
	{

		map<int, int> visited;

		for (int i = 0; i < V; i++)
			visited[i] = 0;

		dfshelper(src, visited);

	}




};

int main()
{

	graph g(5);

	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(0, 3);
	g.addedge(3, 4);


	g.printadjlist();


	g.dfs(0);



	return 0;
}
