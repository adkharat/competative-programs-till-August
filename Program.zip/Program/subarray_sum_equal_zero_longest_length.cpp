#include<iostream>
#include<bits/stdc++.h>

using namespace std;

void print_subarray(int *arr, int s, int e, int &longest_subarray) {
	int sum = 0 ;
	for (int i = s; i <= e; i++) {
		sum += arr[i];
	}

	if (sum == 0) longest_subarray = max(e - s + 1, longest_subarray);
	cout << "Sum = " << sum << " " << "length" << longest_subarray << endl;
}




int main()
{
	int n; cin >> n;

	int *arr = new int [n];

	int longest_subarray = 0;


	for (int i = 0; i < n; i++)
	{
		cin >> arr[i];
	}
	cout << endl;

	for (int s = 0; s < n; s++)
		for (int e = s; e < n; e++)
			print_subarray(arr, s, e, longest_subarray);



	return 0;
}