#include <iostream>
#include<bits/stdc++.h>
using namespace std;

int mini_jump(int arr[], int n) {

	int DP[n] = {INT_MAX};
	DP[0] = 0; //mini jump when we are at index 0 is 0 i.e. base case
	//similar LIS
	for (int i = 1; i <= n; i++) {
		for (int j = 0; j < i; j++) {
			if (j + arr[j] > i)
				DP[i] = min(DP[i], 1 + arr[j]);
		}
	}

	return DP[n];
}

int main() {

	int arr[] = {2, 1, 3, 2, 3, 4, 5, 1, 2, 8};

	int n = sizeof(arr) / sizeof(arr[0]);

	cout << "Minimum Jump are " << mini_jump(arr, n) << endl;

	return 0;
}