#include<bits/stdc++.h>

using namespace std;

void alloccurance(int *arr, int index, int n, int key)
{

	if (index == n)
		return;

	if (arr[index] == key)
		cout << index << " ";

	alloccurance(arr, index + 1, n, key);
}


// int lastoccurance(int *arr, int n, int key)
// {
// 	if (n == 0)
// 		return -1;

// 	int idx = lastoccurance(arr + 1, n - 1, key);
// 	if (idx == -1) { //If Remaining part(e.g. last part) say elemet is not present
// 		if (arr[0] == key) //current part say elemt is present
// 			return 0;
// 		else
// 			return -1;//current part say elemt is not present
// 	}
// 	return idx + 1; //Remaining part say elemet is  present

// }

/*int firstoccurance(int *arr, int n, int key)
{
	if (n == 0)
		return -1;

	if (arr[0] == key)
		return 0;

	int pos = firstoccurance(arr + 1, n - 1, key);

	if (pos == -1)
		return -1;

	return pos + 1;
}*/

// int firstoccurance_2(int *arr, int n, int index, int key)
// {
// 	if (index == n)
// 		return -1;

// 	if (arr[index] == key)
// 		return index;

// 	return firstoccurance_2(arr, n - 1,  index + 1, key);
// }

int main()
{
	int n; cin >> n;
	int arr[n];

	for (int i = 0; i < n; i++)
		cin >> arr[i];
	int key; cin >> key;

//	cout << "First Occurance " << firstoccurance_2(arr, n, 0, key) << endl;
//	cout << "First Occurance " << firstoccurance(arr, n, key) << endl;
	//cout << "last Occurance " << lastoccurance(arr, n, key) << endl;
	cout << "all Occurance " <<  endl;
	alloccurance(arr, 0, n, key);



	return 0;
}