#include<iostream>
#include<bits/stdc++.h>
using namespace std;

template<typename T>
class graph
{

	map<T, list<T> > m;

public:

	void addedge(T src, T dest)
	{

		m[src].push_back(dest);
		m[dest].push_back(src);

	}

	void printadjlist()
	{

		for (auto node_pair : m) {
			cout << node_pair.first << " -->";
			for (auto nbr : node_pair.second)
			{
				cout << nbr << " ,";
			}
			cout << endl;
		}

	}

	int dfshelper(T src, map<T, bool> &visited)
	{
		cout << src << "-->";
		visited[src] = 1;
		int node_count = 1;

		for (auto nbr : m[src])
		{
			if (!visited[nbr])
				node_count += dfshelper(nbr, visited);
		}

		return node_count;
	}


	void dfs(T src)
	{

		map<T, bool> visited;

		for (auto node_pair : m) {
			T node = node_pair.first;
			visited[node] = 0;
		}

		//Above initilization must be only one time
		int component = 0;
		int  node_count = 0;
		vector<int> v;

		//DFS + for each component = count component + count no. of node in each component
		for (auto x : visited)
		{
			if (x.second == 0)
			{	component++;
				node_count = dfshelper(x.first, visited);
				v.push_back(node_count);
				cout << "Node count in component " << component << " is " << node_count << endl;

			}
		}

		cout << endl << "No. of component are " << component << endl;

		//Multiply size of each component==no. of ways to form group with 1 member from each group
		int result = 1;
		for (int i = 0; i < component; i++)
			result *= v[i];

		cout << "no. of ways to form group " << result << endl;

	}





};

int main()
{

	graph<int> g;

	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(0, 3);
	g.addedge(3, 4);

	g.addedge(5, 6);
	g.addedge(6, 7);
	g.addedge(7, 5);

	g.addedge(10, 11);
	g.addedge(12, 13);
	g.addedge(11, 12);


	g.printadjlist();


	g.dfs(0);



	return 0;
}
