#include<bits/stdc++.h>
using namespace std;

class LRUCache {

	int cachesize;

//Doublly link-list to sort newest and oldest element
	list<int> dl;

//Efficiently seacrh <key, address of cache element>
	unordered_map<int, list<int>::iterator> mp;

public:
//constructor to initilize cache 4 frames
	LRUCache(int size) {
		cachesize = size;
	}


//one by one make reference
	void cacheReference(int x)
	{
		//Cache Miss

		//Cache is full and miss
		if (mp.find(x) == mp.end()) { //cache misss
			if (dl.size() == cachesize) { //cache is full
				//back of queue we have oldest element
				//front of queue we have newest element
				//delet oldest element

				//make space for new element
				int last = dl.back();

				dl.pop_back();

				mp.erase(last);

			}
		}
		else //Cache has referenced element. simply bring it to newest element
			dl.erase(mp[x]);

		//Update the reference
		dl.push_front(x);

		mp[x] = dl.begin();

	}


	void display() {
		for (auto x : dl) {
			cout << x << " ";
		}
		cout << endl;
	}
};

int main() {

	LRUCache ca(4);

	ca.cacheReference(1);
	ca.cacheReference(2);
	ca.cacheReference(3);
	ca.cacheReference(1);
	ca.cacheReference(4);
	ca.cacheReference(5);

	ca.display();

	return 0;
}