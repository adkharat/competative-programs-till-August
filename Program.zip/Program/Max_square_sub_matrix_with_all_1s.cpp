#include<iostream>
#include<bits/stdc++.h>
#define R 6
#define C 5
using namespace std;

// /Maximum size square sub-matrix with all 1s

void print_MAX_Square_submatrix(bool M[R][C]) {

	int S[R][C];

	/* Set first row of S[][]*/
	for (int i = 0; i < C; i++)
		S[0][i] = M[0][i];

	/* Set first column of S[][]*/
	for (int i = 0; i < R; i++)
		S[i][0] = M[i][0];

	/* Construct other entries of S[][]*/
	for (int i = 1; i < R; i++)
	{
		for (int j = 1; j < C; j++)
		{
			if (M[i][j] == 1) {
				S[i][j] = min(S[i - 1][j - 1], min(S[i - 1][j], S[i][j - 1])) + 1;
			}
			else //M[i][j]==0
				S[i][j] = 0;

		}
	}

//Print DP array
	for (int i = 0; i < R; i++) {
		for (int j = 0; j < C; j++) {
			cout << S[i][j] << " ";
		}
		cout << endl;
	}

	//Find Maximum value in 2-D array indicating Max square Sub Matrix
	int max_square_matrix = S[0][0];
	for (int i = 0; i < R; i++)
		for (int j = 0; j < C; j++) {
			//max_square_matrix = max(max_square_matrix, *max_element(S[i], S[i] + C));
			if (max_square_matrix < S[i][j])
				max_square_matrix = S[i][j];
		}

	cout << "Maximum max_square_matrix " << max_square_matrix << endl;

	for (int i = 0; i < max_square_matrix; i++) {
		for (int j = 0; j < max_square_matrix; j++) {
			cout << 1 << " ";
		}
		cout << endl;
	}


}

int main() {

	bool M[R][C] = {{0, 1, 1, 0, 1},
		{1, 1, 0, 1, 0},
		{0, 1, 1, 1, 0},
		{1, 1, 1, 1, 0},
		{1, 1, 1, 1, 1},
		{0, 0, 0, 0, 0}
	};

	//int n = sizeof(M) / sizeof(M[0][0]);
	print_MAX_Square_submatrix(M);

	return 0;
}