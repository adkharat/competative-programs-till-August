#include <bits/stdc++.h>
using namespace std;
#define ll long long int
#define ld long double
#define F first
#define S second
#define P pair<int,int>
#define pb push_back

const int N = 100005, M = 22;


vector<int> gr[N]; //Structure of Graph
int visited[N]; //0 means not visited, 1 means set-I (even), 2 means set-II (ODD)
bool ODD_cycle = 0;
//Graph  is Bi-partite if it don't have ODD length cycle
//How to detect ODD length cycle?
//We know we use DFS to detect cycle
//additionally, we will use color 2 colour (0/1/2) to detect ODD length
//For even length COL[curr_node]!=COL[nbr_not_parent]
//For odd length COL[curr_node]==COL[nbr_not_parent]

void dfs(int src, int parent, int col = 1) {
	visited[src] = col;

	//Travel unvisited neighbour
	for (auto nbr : gr[src]) {
		if (!visited[nbr])
			dfs(nbr, src, 3 - col);
		else if (visited[nbr] and nbr != parent and col == visited[nbr])
			ODD_cycle = 1;
	}
}

void solve() {
	int  n, m;
	cin >> n >> m;
	for (int i = 0; i < m; i++) {

		int x, y; cin >> x >> y;
		gr[x].pb(y);
		gr[y].pb(x);
	}

	dfs(1, 0, 1); //1 based indexing
	if (!ODD_cycle)
		cout << "Bipartitie" << endl;
	else
		cout << "Not Bipartitie" << endl;
}

int main()
{

	solve();
	//isBipartite(G) ? cout << "Yes" : cout << "No";
	return 0;
}