#include<iostream>

#include<bits/stdc++.h>

using  namespace std;

void rotate(vector<int> &v, int n) {

	int temp = v[0];
	int i;
	for (i = 0; i < n - 1; i++)
	{
		v[i] = v[i + 1];
	}

	v[i] = temp;

}

int  main() {

	vector<int> v = {1, 2, 3, 4, 5, 6, 7};

	int d = 2;

	int n = v.size();

	for (int i = 0; i < d; i++) {
		rotate(v, n);
	}


	for (auto x : v)
		cout << x << " ";

	return 0;
}