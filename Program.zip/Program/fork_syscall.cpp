#include<bits/stdc++.h>
#include<>
#include<cstdlib>
#include<sys/types.h>
using namespace std;

int main() {

	//pid_t process_id =
	fork();

	cout << "Hello Ajay";

	return 0;
}