#include<iostream>
#include<bits/stdc++.h>

using namespace std;

class node
{
public:
	int data;
	node *link;
};


void push_node_front(node **head_ref, int data_item) {


	node *new_node = new node();

	new_node->data = data_item;
	new_node->link = (*head_ref);

	(*head_ref) = new_node;
}


void print_list(node *head) {
	cout << endl;
	node *temp = head;
	while (temp != NULL) {
		cout <<  temp->data << " ";
		temp = temp->link;
	}
}


void delete_node(node **head_ref, int key) {

	node *temp = *head_ref, *prev;

	if (temp != NULL && temp->data == key) {
		(*head_ref) = temp->link;
		free(temp);
		return;
	}

	while (temp != NULL && temp->data != key)
	{
		prev = temp;
		temp = temp->link;
	}

	//If reached end of list. Key not found
	if (temp == NULL) return;

	//If key found. Delete it
	prev->link = temp->link;
	free(temp);

}

// /Delete a Linked List node at a given position

void delete_node_at_position(node **head_ref, int position)
{

	if ((*head_ref) == NULL)
		return;

	node * temp = (*head_ref);
	if (temp != NULL && position == 0)
	{
		(*head_ref) = temp->link;
		free(temp);
		return;
	}

	for (int i = 0; i < position - 1 && temp != NULL; i++)
		temp = temp->link;	//Temp pointing to one less than position node

	if (temp == NULL || temp->link == NULL) return; //Position is greater than no of nodes in list

	//Position is in list nodes avaialable

	node * next = temp->link ;

	temp-> link = next->link;

	free(next);

	return;

}

void delete_link_list_completely(node **head_ref)
{
	if ((*head_ref) == NULL) return;
	if ((*head_ref)->link == NULL) {
		free(*head_ref);
		*head_ref = NULL;
		return;
	}

	node * temp = (*head_ref), *prev;

	while (temp->link != NULL) {
		prev = temp;
		temp = temp->link;
		free(prev);
	}

	free(temp);

	*head_ref = NULL;

	return;
}

int ssl_length_itteration(node **head_ref) {
	node *temp = *head_ref;
	int count = 0;
	while (temp != NULL) {
		count++;
		temp = temp->link;
	}

	return count;
}


int ssl_length_recursion(node *head) {

	if (head == NULL)
		return 0;

	return 1 + ssl_length_recursion(head->link);
}

bool serach_ssl_itteration(node *head, int key) {

	node * temp = head;

	while (temp != NULL) {
		if (temp->data == key)
			return true;

		temp = temp->link;
	}
	return false;
}


bool serach_ssl_recursion(node *head, int key) {

	if (head == NULL) return false;

	if (head->data == key) return true;

	return serach_ssl_recursion(head->link, key);

}

int get_nth_node_itteration(node *head, int k) {
	node *temp = head;
	int i = 0;
	for (i = 0; i < k && temp != NULL; i++) {
		temp = temp->link;
	}

	if (i == k && temp != NULL) return (temp->data);

	return -1;

}

int get_nth_node_recursion(node *head, int k) {

	if (head == NULL) return -1;

	static int count = 0;
	if (count == k) return head->data;

	count++;
	return get_nth_node_recursion(head->link, k);

}


int count_all_occu_of_key_itteration(node *head, int key) {
	int count = 0;
	while (head != NULL) {
		if (key == head->data)
			count++;
		head = head->link;
	}

	return count;
}

int count_all_occu_of_key_recursion(node *head, int key) {

	static int count = 0;

	if (head == NULL) return count;


	if (head->data == key)
		count++;
	return count_all_occu_of_key_recursion(head->link, key);
}

void middel_element(node *head) {
	if (head != NULL) {
		node *slow, *fast; slow = fast = head;

		while (fast != NULL and fast->link != NULL) {
			slow = slow->link;
			fast = fast->link->link;
		}

		cout << "middel_element " << slow->data << endl;

	}


	return;
}

bool detect_loop(node *head) {

	node *slow, *fast; slow = fast = head;

	while (fast != NULL and slow != NULL and fast->link != NULL) {

		slow = slow->link; //Run in step of 1
		fast = fast->link->link; //Run in step of 2

		if (slow == fast) return true; //If both meet up then return true
	}


	return false;
}

bool detect_loop_flag(node *head)
{
	set<node*> s;

	while (head != NULL) {

		if (s.find(head) != s.end())
			return true;

		s.insert(head);
		head =  head->link;
	}

	return false;

}

node* detect_loop_start(node *head) {
	node *slow, *fast;
	slow = fast = head;
	while (slow != NULL and fast != NULL) {
		slow = slow->link;
		fast = fast->link->link;
		if (slow == fast) {
			break;
		}
	}

	if (slow != fast) return;


	if (slow == fast) {
		slow = head;

		while (slow != fast) {
			slow = slow->link;
			fast = fast->link;
		}
	}

	return slow;
}

int length_of_cycle(node *head) {

	node *slow, *fast; slow = fast = head;
	int len = 1;

	while (slow and fast and fast->link != NULL) {

		slow = slow->link;
		fast = fast->link->link;

		if (slow == fast) {

			while (slow->link != slow) {
				len++;
				slow = slow->link;
			}
			return len;

		}

	}

	return 0;

}

void check_length_even_odd(node* head) {
	node *slow, *fast;
	slow = fast = head;
	while (1) {
		slow = slow->link;
		fast = fast->link->link;

		if (fast == NULL)
		{
			cout << "Even length" << endl;
			return;
		}
		if (fast->link == NULL) {
			cout << "ODD length" << endl;
			return;
		}

	}
}


int main()
{

	node *head = NULL;
	push_node_front(&head, 5);
	push_node_front(&head, 9);
	push_node_front(&head, 3);
	push_node_front(&head, 10);
	push_node_front(&head, 7);
	push_node_front(&head, 7);
	push_node_front(&head, 7);

	print_list(head);

	int key = 3;

	delete_node(&head, key);

	print_list(head);

	delete_node_at_position(&head, 3);
	print_list(head);

	//delete_link_list_completely(&head);
	cout << endl << ssl_length_itteration(&head) << endl;
	cout << endl << ssl_length_recursion(head) << endl;
	print_list(head);
	cout << endl << serach_ssl_itteration(head, 70) << endl;
	cout << endl << serach_ssl_recursion(head, 7) << endl;
	cout << endl << get_nth_node_itteration(head, 2) << endl;
	cout << endl << get_nth_node_recursion(head, 2) << endl;
	cout << endl << count_all_occu_of_key_itteration(head, 7) << endl;
	cout << endl << count_all_occu_of_key_recursion(head, 7) << endl;
	middel_element(head);
	cout << endl << detect_loop(head) << endl;
	cout << endl << detect_loop_flag(head) << endl;
	cout << endl << length_of_cycle(head) << endl;
	detect_loop_start(head);



	return 0;
}