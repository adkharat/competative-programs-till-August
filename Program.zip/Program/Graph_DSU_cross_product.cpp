#include<iostream>
#include<bits/stdc++.h>
#define pb push_back

using namespace std;

class DSU {

	vector<int> parent; //To hold super parent of every element
	vector<int> sz;
	int total_comp;

public:

	//Initially parent of every node is itself only
	void init(int n) {
		parent.clear(); parent.resize(n);
		sz.clear(); sz.resize(n);
		//iota(parent.begin(), parent.end(), 0);
		for (int i = 0; i < n; i++) {
			parent[i] = i;
			sz[i] = 1;
		}
		total_comp = n;
	}

	int get_superparent(int x) {
		if (parent[x] == x)return x;
		else return parent[x] = get_superparent(parent[x]);
	}

	//Merge/union of disjoint component
	void union_compo(int x, int y) {
		int superParent_x = get_superparent(x);
		int superParent_y = get_superparent(y);
		if (superParent_x != superParent_y) {
			parent[superParent_x] = superParent_y;
			sz[superParent_y] += sz[superParent_x]; //Donate all its node count to new componenet
			sz[superParent_x] = 0;
			total_comp--;
		}
		else
			cout << "Cycle exist " << endl;
	}

	void printComp(int n) {
		cout << "Total Component after union " << total_comp << endl;

		for (int i = 0; i < n; i++) cout << parent[i] + 1 << " ";
		cout << endl;
		for (int i = 0; i < n; i++) cout << sz[i] << " ";


		int ans = 0;
		//For every vertex, find in how many ways it can be connected to other component.
		for (int i = 0; i < n; i++) {//i is considered as X
			int superParent_i = get_superparent(i); //Always superparent will tell what is size of its component
			ans += n - sz[superParent_i]; //In one comp its X then in other comp it will be n-X
		}

		cout << "\n No of ways such that 2 set can be connected are " << ans / 2 << endl;
	}



};

void solve() {

	int n, m; cin >> n >> m;
	//To store edges{x,y,wt} use 2D-Array
	//We have m edges 0,1,2,...m. At each index store one edge;
	//vector<vector<int>> edges(m);

	DSU g;

	g.init(n);//index 0 to (n-1) //0 based INDEX

	//Take input this edges
	for (int i = 0; i < m; i++) {
		int x, y; cin >> x >> y ; //Get input in 1 based indexing
		x--; y--; //Convert back to 0 based indexing
		//edges[i] = {x, y}; //store 2 Columns at each row index
		g.union_compo(x, y);
	}




	g.printComp(n);
}

int main() {

	solve();

	return 0;
}

/*
5 2
1 2
3 4
*/
/*
6 4
1 2
2 3
4 5
5 6
*/