#include <bits/stdc++.h>
using namespace std;



int main() {

	vector<int> v = { -2, 1, 6, -3};
	int x = 3;

	int l = 0, r = 0;
	int curr_avr = 0;
	int max_avr = INT_MIN;

	for (int i = 0; i < v.size(); i++) {

		curr_avr = curr_avr +

	}



	return 0;
}