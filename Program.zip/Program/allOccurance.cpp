#include<iostream>
#include<bits/stdc++.h>

using namespace std;

/*void allOccur(int a[], int n, int key) {

	for (int i = 0; i < n; i++) {
		if (a[i] == key) cout << i << " ";
	}

}
*/

/*void allOccur(int a[], int n, int i, int key) {
	if (i == n) return;
	if (a[i] == key) cout << i << " ";

	allOccur(a, n, i + 1, key);

}*/


int allOccur(int *arr, int n, int i, int *out, int j, int key) {

	if (i == n) { return j;}

	if (arr[i] == key) { out[j] = i; j++; cout << i << " ";}

	return allOccur(arr, n, i + 1, out, j, key);



}

// Driver program
int main()
{
	int a[] = { 1, 7, 4, 2, 7, 7, 8, 7};
	int n = sizeof(a) / sizeof(a[0]);
	int out[n] = {0};
	cout << "Occurance  = " << endl;
	cout << endl << allOccur(a, n, 0, out, 0, 7) ;
	return 0;
}