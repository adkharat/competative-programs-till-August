#include<iostream>
#include<bits/stdc++.h>

using namespace std;

int lps(string s1) {

	int n = s1.size();

	int DP[n][n] = {0};

	//LPS of length 1
	for (int i = 0; i < n; i++)
		DP[i][i] = 1;


	for (int curr = 2; curr <= n ; curr++)
	{
		for (int i = 0; i < n - curr + 1; i++)
		{
			int j = i + curr - 1;

			if (s1[i] == s1[j] and curr == 2)
				DP[i][j] = 2;
			else if (s1[i] == s1[j])
				DP[i][j] = DP[i + 1][j - 1] + 2;
			else
				DP[i][j] = max(DP[i][j - 1], DP[i + 1][j]);
		}
	}

	return DP[0][n - 1];

}

int main()
{
	int t; cin >> t;

	while (t--) {

		string s1; cin >> s1;
		cout << "Longest Palindrome Subsequence " << lps(s1);
	}

	return 0;
}