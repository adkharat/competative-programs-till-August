#include<iostream>
#include<bits/stdc++.h>

using namespace std;


int main()
{
	int arr[] = {1, 4, 2, 10, 2, 3, 1, 0, 20 };
	int n = sizeof(arr) / sizeof(arr[0]);

	int k; cin >> k;
	int max_sum = 0;
	int win_sum = INT_MIN;

	for (int i = 0; i <= n - k; i++)
	{
		win_sum = 0;
		cout << i << " win_sum " << win_sum << " ";
		for (int j = 0; j < k; j++) {
			win_sum +=	arr[i + j];
		}
		max_sum = max(max_sum, win_sum);
		cout << " win_sum " << win_sum << " ";
		cout << "max_sum " << max_sum << endl;
	}

	cout << "Maximum sum subarray of size K is " << max_sum << endl;

	return 0;
}
