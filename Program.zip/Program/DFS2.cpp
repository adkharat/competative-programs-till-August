#include<iostream>
#include<bits/stdc++.h>
using namespace std;

template<typename T>
class graph
{

	map<T, list<T> > m;

public:

	void addedge(T src, T dest)
	{

		m[src].push_back(dest);
		m[dest].push_back(src);

	}

	void printadjlist()
	{

		for (auto node_pair : m) {
			cout << node_pair.first << " -->";
			for (auto nbr : node_pair.second)
			{
				cout << nbr << " ,";
			}
			cout << endl;
		}

	}

	void dfshelper(T src, map<T, bool> &visited)
	{
		cout << src << "-->";
		visited[src] = 1;

		for (auto nbr : m[src])
		{
			if (!visited[nbr])
				dfshelper(nbr, visited);
		}

	}


	void dfs(T src)
	{

		map<T, bool> visited;

		for (auto node_pair : m) {
			T node = node_pair.first;
			visited[node] = 0;
		}


		dfshelper(src, visited);

	}




};

int main()
{

	graph<int> g;

	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(0, 3);
	g.addedge(3, 4);


	g.printadjlist();


	g.dfs(0);



	return 0;
}
