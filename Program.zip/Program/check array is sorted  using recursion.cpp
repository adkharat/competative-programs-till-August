#include <iostream>
#include <bits/stdc++.h>
using namespace std;

bool f1(int arr[], int n)
{
	if (n == 1 or n == 0 )
		return true;
	if (arr[0] > arr[1] and f1(arr + 1, n - 1))
		return true;
	else
		return false;

}


int   main()
{

	int t; cin >> t;
	cout << (2 > 3) << endl;
	while (t--) {
		int n; cin >> n;
		int arr[n];
		for (int i = 0; i < n; i++)
			cin >> arr[i];
		cout << "Last element " << arr[n] << endl;
		cout << f1(arr, n);

	}

	return 0;
}