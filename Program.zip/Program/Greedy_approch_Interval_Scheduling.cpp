#include<iostream>
#include<bits/stdc++.h>

using namespace std;

//I can do 10 activuity in a day.
//Maximize no of interval (work done) such that no one overlap with other activity
//sort --> start time --> fails , if strating activity remains busy for longer time(e.g. class room)
//sort --> Duration -->fails, if it overlap with before and after activity
//sort --> End Time --> pass,  Maximize the no of activity
// 6
// 10 13
// 9 14
// 7 11
// 12 16
// 20 25
// 1 50
bool compare(pair<int, int> p1, pair<int, int> p2) {
	return p1.second < p2.second;

}

int main()
{
	int n; cin >> n ;
	vector<pair<int, int> > v;

	for (int i = 0; i < n; ++i)
	{
		int x, y; cin >> x >> y;
		v.push_back(make_pair(x, y));
	}

	for (int i = 0; i < n; ++i)
	{
		sort(v.begin(), v.end(), compare);
	}

	vector<pair<int, int>> res;
	res.push_back(v.front());

	for (auto x = v.begin() + 1; x != v.end(); x++) {
		if (x->first >= (res.back()).second)
			res.push_back(make_pair(x->first, x->second));
	}

	cout << "Maximum no. of Non-overlapping activuity selected " << res.size() << endl;

	for (auto x : res) {
		cout << "(" << x.first  << ", " << x.second << ")" << " ";
	}

	return 0;
}
