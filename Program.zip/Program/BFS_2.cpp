#include<iostream>
#include<bits/stdc++.h>
using namespace std;

template<typename T>
class graph
{

	map<T, list<T> > m;

public:


	void addedge(T src, T dest)
	{

		m[src].push_back(dest);
		m[dest].push_back(src);
	}


	void printadjlist()
	{

		for (auto city : m)
		{
			T src = city.first;
			list<T> nbrs = city.second;

			cout << src << "-->";

			for (auto nbr : nbrs)
			{
				cout << nbr << ",";
			}

			cout << endl;
		}
	}


	void dfshelper(queue<T> &q, map<T, bool> &visited)
	{

		while (!q.empty())
		{
			int expl = q.front();
			//cout<<q.front()<<" ";
			q.pop();

			cout << expl << " --> ";
			for (auto nbr : m[expl])
			{
				if (!visited[nbr]) {
					q.push(nbr);
					visited[nbr] = 1;
				}

			}

		}

	}

	void bfs(T src)
	{
		queue<int> q;
		map<T, bool> visited;


		q.push(src);
		visited[src] = 1;

		dfshelper(q, visited);


	}



};


int main()
{

	graph<int> g;

	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(0, 3);
	g.addedge(3, 4);


	g.printadjlist();


	g.bfs(0);

	return 0;
}