#include<iostream>
#include<bits/stdc++.h>

using namespace std;

class node
{
public:
	int data;
	node *left;
	node *right;
};

int height_of_tree(node *root) {
	if (root == NULL)
		return 0;
	int l_height = height_of_tree(root->left);
	int r_height = height_of_tree(root->right);

	return (l_height > r_height) ? 1 + l_height : 1 + 	r_height;
	//return max(l_height, r_height) + 1;
}

int diameter_of_tree(node *root) {

	int l_height = height_of_tree(root->left);
	int r_height = height_of_tree(root->right);
	int l_diameter = diameter_of_tree(root->left);
	int r_diameter = diameter_of_tree(root->right);

	return max(l_height + r_height + 1, max(l_diameter , r_diameter));
}

node* create_node(int data) {

	node *new_node =  new node();

	new_node->data = data;
	new_node->left = NULL;
	new_node->right = NULL;

	return new_node;
}

node* create_node(char data) {

	node *new_node =  new node();

	new_node->data = data;
	new_node->left = NULL;
	new_node->right = NULL;

	return new_node;
}

bool serach_BST1(node *root, int key) {

	if (root == NULL) return false;
	else if (key == root->data) return true;
	else if (key <= root->data) return serach_BST1(root->left, key);
	else return serach_BST1(root->right, key);

}

node * serach_BST2(node *root, int key) {
	// Base Cases: root is null or key is present at root
	if (root->data == key)
		return root;
	else if (key <= root->data)
		return serach_BST2(root->left, key);
	else if (key > root->data)
		return serach_BST2(root->right, key);

	return NULL;
}

node* getmini(node *node) {

	if (node->left == NULL)
		return node;

	return getmini(node->left);
}

node * inorder_successor_of_node(node *root, node *key) {

	//node *curr = serach_BST2(key);
	//Case 1 : - Right subtree for given node exist
	if (key->right != NULL) {
		node *m = getmini(key->right); //Get minimum from right subtree
		return m;
	}
	//case 2: nearest ancestore of given node for which this node lies in its left sub tree
	//start from root
	node *succ = NULL;
	while (root != NULL) {
		if (key->data <= root->data) {
			succ = root; //don't stop here. go for nearest neighbour
			root = root->left;
		}
		else if (key->data > root->data) {
			root = root->right;
		}
	}

	return succ;
}

node* help_build_tree(char in[], char pre[], int instart, int inend, map<char, int> &mp) {

	static int pre_index = 0;

	if (instart > inend)
		return NULL;

	//Element from pre_order and incre for next call
	char curr = pre[pre_index++];

	//Build new tree with curr as elemnt node
	node* temp_node = create_node(curr);

	//If this node has no children then return
	if (instart == inend)
		return temp_node;

	//Get index of pre_order head in inorder
	int in_index = mp[curr];

	temp_node->left  = help_build_tree(in, pre, instart, in_index - 1, mp);
	temp_node->right = help_build_tree(in, pre, in_index + 1, inend, mp);

	return temp_node;
}

node * tree_from_inorder_preoreder(char in[], char pre[], int len) {
	map<char, int> mp;
	for (int i = 0; i < len; i++)
		mp[in[i]] = i;

	return help_build_tree(in, pre, 0, len - 1, mp);
}




node* insert_in_BST(node * root, int data) {
	if (root == NULL) {
		root = create_node(data);

	}

	else if (data <= root->data) {
		root->left =  insert_in_BST(root->left, data);
	}
	else
		root->right = insert_in_BST(root->right, data);

	return root;

}

//similar to preordere traversal
int size_of_binary_tree(node * root) {
	if (root == NULL)
		return 0;

	return 1 + size_of_binary_tree(root->left) + size_of_binary_tree(root->right);

	//return root ? (1 + size_of_binary_tree(root->left) + size_of_binary_tree(root->right) ) : 0;
}

//exchange left subtree with right subtree
void get_mirror(node *root) {
	if (root == NULL)
		return;
	get_mirror(root->left);
	get_mirror(root->right);
	swap(root->left, root->right);
	// node *temp = root->left;
	// root->left = root->right;
	// root->right = temp;
}

//Similar to pre-order traversal root->left->right
int compare_two_trees(node *root1, node *root2) {
	if (root1 == NULL and root2 == NULL)
		return 1;

	if (root1 != NULL and root2 != NULL) {
		return (root1->data == root2->data) && compare_two_trees(root1->left, root2->left) && compare_two_trees(root1->right, root2->right);
	}
	return 0;
}

//If both node fall/lies on same side then move to either LHS/RHS
node* LCA_BST_itterative(node* root, int n1, int n2) {
	while (root != NULL) {
		if (n1 < root->data and n2 < root->data)
			LCA_BST_itterative(root->left, n1, n2); //Both n1 and n2 lie on LHS of Root
		else if (n1 > root->data and n2 > root->data)
			LCA_BST_itterative(root->right, n1, n2); //Both n1 and n2 lie on RHS of Root
		else
			break; //both node n1 and n2, don't lies on same side
	}

	return root;
}

//If both node fall/lies on same side then move to either LHS/RHS
node * LCA_BST_recursive(node *root, int n1, int n2) {
	if (root == NULL)
		return root;

	if (n1 < root->data and n2 < root->data)
		LCA_BST_recursive(root->left, n1, n2); //Both n1 and n2 lie on LHS of Root
	if (n1 > root->data and n2 > root->data)
		LCA_BST_recursive(root->right, n1, n2); //Both n1 and n2 lie on RHS of Root

	return root; //both node n1 and n2, don't lies on same side

}

node * LCA_BT_recursive(node *root, int n1, int n2) {
	if (root == NULL) //If not present then return null
		return root;

	//Root hold both either of vertex data
	if (root->data == n1 || root->data == n2)
		return root;

	node *left = LCA_BT_recursive(root->left, n1, n2);
	node *right = LCA_BT_recursive(root->right, n1, n2);

	if (left && right) //this is ancestor node
		return root;

	return left ? left : right; //If present in only one side then return that particular side
}

//similar to preorder traversal O(n)
int get_level_of_key_BT(node *root, int level, int key) {

	if (root == NULL)
		return -1;
	if (root == key)
		return level;
	int level2 = get_level_of_key_BT(root->left, level + 1, key);
	if (level2 != -1)
		return level2;
	return get_level_of_key_BT(root->right, level + 1, key);

}

//similar to pre-order traversal O(n)
void print_nodes_at_k_distance_from_root(node* root, int dist, int k) {
	id(root != NULL) {
		if (dist == k) {
			cout << root->data << " ";
			return;
		}
		print_nodes_at_k_distance_from_root(root->left, dist + 1, k);
		print_nodes_at_k_distance_from_root(root->right, dist + 1, k);
	}

}

void inorder(node * root) {
	if (root == NULL)
		return;
	inorder(root->left);
	cout << root->data << " ";
	inorder(root->right);

}

void preorder(node * root) {
	if (root == NULL)
		return;
	cout << root->data << " ";
	preorder(root->left);
	preorder(root->right);
}

void postorder(node * root) {
	if (root == NULL)
		return;

	postorder(root->left);
	postorder(root->right);
	cout << root->data << " ";
}


void level_order_traversal(node * root) {
	if (root == NULL)
		return;
	queue<node *> q;
	q.push(root);

	while (!q.empty()) {
		node *temp = q.front();

		cout << temp->data << " ";
		q.pop();
		if (temp->left != NULL)
			q.push(temp->left);
		if (temp->right != NULL)
			q.push(temp->right);
	}
}

int main() {
	node *root1 = NULL; //node *root2 = NULL;
	int n1; //int n2;
	cin >> n1;
	//cin >> n2;
	while (n1--) {
		int x; cin >> x;
		root1 = insert_in_BST(root1, x);
	}
	/*while (n2--) {
		int x; cin >> x;
		root2 = insert_in_BST(root2, x);
	}*/


	cout << "In Order Traversal " << " "; inorder(root1); //O(n)
	cout << endl;
	cout << "Pre Order Traversal " << " "; preorder(root1); //O(n)
	cout << endl;
	cout << "Post Order Traversal " << " "; postorder(root1); //O(n)
	cout << endl;
	cout << "Level Order Traversal " << " "; level_order_traversal(root1); //O(n)
	cout << endl;
	//cout << serach_BST(root1, 5) << endl;
	//node *succ = inorder_successor_of_node(root1, root->left);
	//cout << succ->data << endl;


	cout << "Size of binary tree " << size_of_binary_tree(root1) << endl;
	/*cout << "Compare two tree " << compare_two_trees(root1, root2) << endl;
	get_mirror(root1);
	preorder(root1);*/

	//cout << "Lowest comman ancestor "; cout << LCA_BST_recursive(root1, 2, 3)->data << endl;
	//cout << "Lowest comman ancestor "; cout << LCA_BST_itterative(root1, 7, 9)->data << endl;
	cout << "Height of tree "; cout << height_of_tree(root1) << endl;
	cout << "diameter_of_tree "; cout << diameter_of_tree(root1) << endl;


	return 0;
}
