#include<iostream>
#include<bits/stdc++.h>

using namespace std;
//Print all sub array of given array with SUM equal to K
// any contigious subarray of sum K

int main()
{
	int arr[] = {1, 2, 3, 10, 6, 4, 2, 1, 0, 20 };
	int n = sizeof(arr) / sizeof(arr[0]);

	int k; cin >> k;

	int l, r; l = r = 0;
	int csum = 0;
	int mini_win = INT_MAX; //Play here to get mini and max

	for (int i = 0; i < n; i++)
	{
		if (csum > k and l < r) {
			csum = csum - arr[l];
			l++;
		}

		if (csum == k) {
			cout << "Array is " << l << " " << r - 1 << endl;
			//To print all subarray use below  2 lines
			mini_win = min(mini_win, r - l); //Play here to get mini and max ELSE comment it
			csum = 0; l = r = i;
			//To print one subarray print below line

			//return 0;
		}

		if (csum < k and r < n) {
			csum += arr[i];
			r++;
		}


	}

	cout << "Mini window is " << mini_win << endl;

	return 0;
}