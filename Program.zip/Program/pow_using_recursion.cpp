#include<bits/stdc++.h>
using namespace std;


int power(int a, int p)
{
	if (p == 0) return 1;
	return a * power(a, p - 1);

}

int main()
{

	int a; cin >> a;
	int p; cin >> p;

	cout << "power " << power(a, p) << endl;

	return 0 ;
}