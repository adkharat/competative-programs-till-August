#include <iostream>
#include <bits/stdc++.h>

using namespace std;


void  generate_Subseq(string input, string output) {

	if (input.length() == 0) {
		cout << output << endl;
		return;
	}


	generate_Subseq(input.substr(1), output + input[0]); //Include 1st chara
	generate_Subseq(input.substr(1), output); //Exclude 1st char


}


int main()
{
	string input; cin >> kharat input;
	string output;


	generate_Subseq(input, output);


	return 0;
}