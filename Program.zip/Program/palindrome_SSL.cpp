#include<iostream>
#include<bits/stdc++.h>

using namespace std;

class node
{
public:
	int data;
	node *link;
};

void print_list(node *head) {
	cout << endl;
	node *temp = head;
	while (temp != NULL) {
		cout <<  temp->data << " ";
		temp = temp->link;
	}
}

void push_node_front(node **head_ref, int data_item) {


	node *new_node = new node();

	new_node->data = data_item;
	new_node->link = (*head_ref);

	(*head_ref) = new_node;
}


bool palindrome_stack(node *head) {

	node *temp = head; //1 2 3 2 1

	stack<int> s;

	while (temp != NULL) {
		s.push(temp->data);
		temp = temp->link;
	}

	temp = head;

	while (temp != NULL && !s.empty())
	{
		if (s.top() == temp->data)
		{
			s.pop();
			temp = temp->link;
		}
		else
			return false;
	}

	return true;

}

void remove_duplic_sorted_ssl(node *head) {

	node *curr, *next_next;
	curr = head;
	while (curr->link != NULL) {

		if (curr->data == curr->link->data) {
			next_next = curr->link->link;
			free(curr->link);
			curr->link = next_next;
		}
		else
			curr = curr->link;
	}

}

void last_to_first(node **head_ref) {

	node *last, *seclast;
	last = (*head_ref);
	while (last->link != NULL) {
		seclast = last;
		last = last->link;
	}

	seclast->link = NULL;

	last->link = (*head_ref);
	(*head_ref) = last;
}

void reverse_SSL_itteration(node **head_ref) {

	node *curr = *head_ref, *prev = NULL, *temp;

	while (curr != NULL) {
		temp = curr->link;
		curr->link = prev;
		prev = curr;
		curr = temp;
	}

	(*head_ref) = prev;
}

node* swap_pair_SSL(node **head_ref) {

	node *p = (*head_ref), *q , *temp;

	node *new_start = p->link;

	while (1) {
		q = p->link;
		temp = q->link;
		q->link = p;
		if (temp == NULL) { //EVEN length
			p->link = temp;
			break;
		}
		if (temp->link == NULL) { //ODD Length
			p->link = temp;
			break;
		}

		p->link = temp->link;
		p = temp;
	}

	return new_start;
}

void pairWiseSwap(node *head) {
	if (head != NULL and head->link != NULL) //Atleast two node in  a list
	{
		swap(head->data, head->link->data);
		pairWiseSwap(head->link->link);
	}
}

void rotate_SSL(node *head, node *r) {
	if (head == NULL) return;

	node *p = head;
	while (p != r) {
		p = p->link;
	}
	node *new_head = p->link;
	node *q = new_node;
	while (q->link != NULL) {
		q = q->link;
	}
	q->link = head;

	r->link = NULL;
}

int main()
{
	node *head = NULL;
	push_node_front(&head, 1);
	push_node_front(&head, 2);
	push_node_front(&head, 3);
	push_node_front(&head, 4);
	push_node_front(&head, 5);

	//cout << endl << palindrome_stack(head) << endl;
	//remove_duplic_sorted_ssl(head);
	print_list(head);

	//last_to_first(&head);
	//reverse_SSL_itteration(&head);
	//head = swap_pair_SSL(&head);
	pairWiseSwap(head);
	print_list(head);


	return 0;
}