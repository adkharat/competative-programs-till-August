#include<iostream>
#include<bits/stdc++.h>
#define N 5
using namespace std;

void printPath(int sol[N][N]) {
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++)
			cout << sol[i][j] << " ";
		cout << endl;
	}
}

bool CheckSafe(int maze[N][N], int x, int y) {
	if (x >= 0 and y <= N - 1 and maze[x][y] == 1) //safe to travel
		return true;

	return false; //Not safe to travel
}

bool solveMazeUtility(int maze[N][N], int x, int y, int sol[N][N]) {
//Base Condition
	if (x == N - 1 and y == N - 1 and maze[x][y] == 1) {
		sol[x][y] = 1;
		return true;
	}
// if I am standing at safe location (x,y) cell //safe location is define as (x,y)==1; then make a recursion call for down and left
	if (CheckSafe(maze, x, y)) {

		sol[x][y] = 1; //Include that cell in output path
		if (solveMazeUtility(maze, x + 1, y, sol)) //Move toward downward cell
			return true;							//Stop here; no need to check for right path or no need to backtrack
		if (solveMazeUtility(maze, x, y + 1, sol) ) //Move toward rightward cell
			return true;							//Stop here; no need to backtrack
		//If no left and right path then backtrack
		sol[x][y] = 0; //Undo changes
		return false;

	}

	return false;
}

void solveMaze(int maze[N][N]) {
	//To hold solution create 2D matrix
	int sol[N][N] = {0};
	bool check = solveMazeUtility(maze, 0, 0, sol); //input, (index position i,j), outputmatrix

	if (check)
		printPath(sol);
	else
		cout << "Path Doesn't exist" << endl;
}

int main() {

	int maze[N][N] = { { 1, 0, 0, 0 , 0},

		{ 1, 1, 0, 1, 0 },

		{ 0, 1, 1, 1, 1 },
		{ 1, 1, 1, 1, 0 },
		{ 0, 1, 1, 1, 1 }
	};

	solveMaze(maze);

	return 0;
}