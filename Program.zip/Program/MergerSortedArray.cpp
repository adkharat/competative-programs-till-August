#include<bits/stdc++.h>

using namespace std;


//Time ComplexityO(m+n)
/*void mergerArray(int *arrm, int *arrn, int m, int n, int *res, int k) {

	int i = 0, j = 0;

	while (i < m and j < n) {

		if (arrm[i] < arrn[j]) {
			res[k] = arrm[i];
			i++; k++;
		}
		else {
			res[k] = arrn[j];
			j++; k++;
		}
	}

	while (i < m) {
		res[k++] = arrm[i++];
	}

	while (j < n) {
		res[k++] = arrn[j++];
	}

}
*/
int res[100];
void mergerArray(int *arr, int s, int e) {


	int mid = (s + e) / 2;
	int i = s, j = mid + 1, k = s;


	while (i <= mid and j <= e) {

		if (arr[i] < arr[j]) {
			res[k++] = arr[i++];

		}
		else {
			res[k++] = arr[j++];
		}
	}

	while (i <= mid) {
		res[k++] = arr[i++];
	}

	while (j <= e) {
		res[k++] = arr[j++];
	}

	//Copy all element to original arrays
	for (int i = s; i <= e; i++)
		arr[i] = res[i];

}



void mergeSort(int *arr, int s, int e) {

//Base case
	if (s == e)
		return;
	//Mid point
	int mid = (s + e) / 2;

	mergeSort(arr, s, mid);
	mergeSort(arr, mid + 1, e);
	mergerArray(arr, s, e);


}


int main()
{
	/*int m; cin >> m;
	int n; cin >> n;
	int arrm[m], arrn[n];
	*/
	//int res[m + n];
	//int k = 0;

	/*for (int i = 0; i < m; i++)
		cin >> arrm[i];

	for (int i = 0; i < n; i++)
		cin >> arrn[i];
	*/

	//int n;cin>>n;

	int arr[] = {10, 9, 8, 7, 6};

	int n = sizeof(arr) / sizeof(arr[0]);


	cout << endl;

	mergeSort(arr, 0, n - 1);
	cout << endl;
	for (int i = 0; i < n; i++)
		cout << arr[i] << " ";
	cout << endl;


	return 0;
}