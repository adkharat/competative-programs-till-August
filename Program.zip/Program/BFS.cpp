#include<iostream>
#include<bits/stdc++.h>
using namespace std;

class graph
{

	int V;
	list<int> *l;


public:

	graph(int v)
	{

		this->V = v;
		l = new list<int> [V];
	}


	void addedge(int src, int dest)
	{

		l[src].push_back(dest);
		l[dest].push_back(src);
	}


	void printadjlist()
	{

		for (int i = 0; i < V; i++)
		{
			cout << i << " --> ";
			for (auto nbr : l[i])
			{
				cout << nbr << ",";
			}
			cout << endl;
		}
	}


	void dfshelper(queue<int> &q, map<int, int> &visited)
	{

		while (!q.empty())
		{
			int expl = q.front();
			//cout<<q.front()<<" ";
			q.pop();

			cout << expl << " --> ";
			for (auto nbr : l[expl])
			{
				if (!visited[nbr]) {
					q.push(nbr);
					visited[nbr] = 1;
				}

			}

		}

	}

	void bfs(int src)
	{
		queue<int> q;
		map<int, int> visited;

		for (int i = 0; i < V; i++)
			visited[i] = 0;

		q.push(src);
		visited[src] = 1;

		dfshelper(q, visited);


	}



};


int main()
{

	graph g(5);

	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(0, 3);
	g.addedge(3, 4);


	g.printadjlist();


	g.bfs(0);

	return 0;
}